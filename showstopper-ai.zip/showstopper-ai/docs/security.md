# Security
- Roles (owner/admin/member/viewer) enforced by `guard()` on every API route; only the owner can approve or edit the manager.
- One tool gate (`authorizeTool`) combines agent enablement, allowed tools, permission level, the always-approve list and manager approval mode.
- Zod validation on all input; consistent error shapes; no stack traces to clients.
- Audit log records time, business, user, agent, action, tool, channel, approval state and result; secrets are redacted.
- Secrets live only in server environment variables; none appear in client bundles, prompts or state responses.
- Basic security headers; in-process rate limit (use Redis or an edge store in production).
- Multi-tenancy: `business_id` on every table with RLS (`db/schema.sql`).
- Known Level 1 gap: the session is a demo cookie, not real authentication.
