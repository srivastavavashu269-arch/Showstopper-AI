# Testing
`npm test` runs 23 Vitest tests: routing, role and tool authorization, approval flow, honest delivery, escalation, knowledge-only support, manager allow-list, channel verification, retrieval, audit redaction and validation.

Also checked against a production build: every page returns 200 and API error paths (400/403/404/409/422) behave as designed.

Not yet covered: browser-level UI tests and visual responsive checks.
