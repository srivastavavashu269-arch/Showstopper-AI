# Roadmap
- **Level 2**: real auth, Postgres repository, NIM inference with tool calling and structured outputs, embeddings and pgvector retrieval, webhook endpoints, background jobs for follow-ups.
- **Level 3**: WhatsApp Cloud API, Gmail OAuth, Meta Instagram, authorized website management, automations engine, advanced analytics, hardened production deployment.
- **Later**: booking/calendar, outbound sales, proposal automation, each with its own permissions and compliance controls.
