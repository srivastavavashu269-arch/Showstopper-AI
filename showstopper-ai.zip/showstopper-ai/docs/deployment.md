# Deployment (Vercel)
1. The Level 1 demo deploys as-is, but state is in memory, so each serverless instance has its own data. Use it for demos only.
2. For production: provision Supabase/Postgres, apply `db/schema.sql`, set env vars from `.env.example` in Vercel, replace the demo session with real auth and the store with a Postgres repository, move rate limiting to a shared store, then connect providers.
3. Never commit `.env`. Server-only secrets must not use the `NEXT_PUBLIC_` prefix.
