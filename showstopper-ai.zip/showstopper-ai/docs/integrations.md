# Integrations
Level 1: all four channels are mocks. A channel is "pending" after details are entered and "connected" only after `verifyConnection()`.

Level 3 adapters (one at a time, each implementing `ChannelProvider`):
- **WhatsApp**: WhatsApp Business Cloud API; webhook signature verification (`WHATSAPP_APP_SECRET`), inbound/outbound, delivery status.
- **Email**: Google OAuth (Gmail); token refresh, drafts, send, revoke. Passwords are never requested.
- **Instagram**: Meta-authorized messaging, publishing and insights where supported.
- **Website**: Mode A public analysis (URL only). Mode B managed access requires real admin/API authorization; a URL is never treated as access.

Tokens are stored encrypted (`channel_connections.encrypted_credentials`) and decrypted only server-side.
