# Database
Apply `db/schema.sql` to Postgres 15+ (or Supabase) with the `vector` extension. It covers users, businesses, business_members, agents, agent_permissions, business_knowledge, knowledge_documents, knowledge_chunks, channel_connections, channel_permissions, customers, conversations, messages, leads, tasks, approvals, audit_events, automations, notifications and agent_runs.

RLS uses `is_member(business_id, min_role)`; only owners can update approvals; channel connections need admin. The schema has not been executed against a live database yet. Level 2 task: implement a Postgres repository matching the `src/lib/store.ts` usage.
