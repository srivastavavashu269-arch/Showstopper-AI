# Architecture
Owner → Central AI Manager → Specialist agents → Authorized tools/integrations.

Request path: API route → session + role guard + rate limit → Zod validation → service (`manager.ts`) → `authorizeTool()` → approval gate → provider adapter → audit log.

- **Repository (`store.ts`)**: Level 1 in-memory, single instance. Level 2 replaces it with Postgres behind the same functions.
- **AI layer (`providers/ai`)**: `AIProvider` interface (`chat`, `embed`). `MockAIProvider` for demo; `NimProvider` targets NVIDIA NIM's OpenAI-compatible API. Selected by `AI_PROVIDER`. Keys are read server-side only.
- **Channels (`providers/channels`)**: `ChannelProvider` interface (connect, disconnect, getStatus, verifyConnection, receiveEvent, sendMessage, listPermissions). Level 1 uses `MockChannelProvider` for all four channels; `registry.ts` is the single swap point.
- **Routing**: rule-based in Level 1 (`decideRoute`), designed to become hybrid (rules plus model classification). The manager enforces its allowed-agent list, escalates sensitive wording, and requires approval for risky tools.
- **Honest delivery**: a send executes only after approval and only through a connected provider. Failures mark the message "blocked" and are audited.
