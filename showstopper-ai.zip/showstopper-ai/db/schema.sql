-- Showstopper-AI schema (PostgreSQL / Supabase-compatible). Level 2 target; Level 1 uses an in-memory repository.
create extension if not exists pgcrypto;
create extension if not exists vector;

create type member_role as enum ('owner','admin','member','viewer');

create table users (id uuid primary key default gen_random_uuid(), auth_user_id uuid unique, email text unique not null, full_name text, created_at timestamptz not null default now());
create table businesses (id uuid primary key default gen_random_uuid(), name text not null, type text, description text, location text, services text, target_customers text, hours text, contact_email text, language text default 'English', website_url text, onboarding_step int not null default 0, onboarding_complete boolean not null default false, created_at timestamptz not null default now());
create table business_members (business_id uuid not null references businesses on delete cascade, user_id uuid not null references users on delete cascade, role member_role not null default 'member', primary key (business_id, user_id));
create index on business_members (user_id);

create table agents (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, key text not null, name text not null, role text, description text, instructions text, enabled boolean not null default true, permission_level text not null default 'act_with_approval', requires_approval boolean not null default true, status text not null default 'idle', last_activity_at timestamptz, unique (business_id, key));
create table agent_permissions (agent_id uuid not null references agents on delete cascade, business_id uuid not null references businesses on delete cascade, tool text not null, primary key (agent_id, tool));

create table business_knowledge (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, category text not null, title text not null, content text not null, approved boolean not null default true, source text, updated_at timestamptz not null default now());
create index on business_knowledge (business_id, category);
create table knowledge_documents (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, knowledge_id uuid references business_knowledge on delete cascade, filename text, storage_path text, created_at timestamptz not null default now());
create table knowledge_chunks (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, knowledge_id uuid references business_knowledge on delete cascade, document_id uuid references knowledge_documents on delete cascade, chunk_index int not null, content text not null, embedding vector(1024), source_label text);
create index on knowledge_chunks (business_id);
create index on knowledge_chunks using hnsw (embedding vector_cosine_ops);

create table channel_connections (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, channel text not null check (channel in ('whatsapp','email','instagram','website')), status text not null default 'disconnected', mode text not null default 'demo', identifier text, verified_at timestamptz, encrypted_credentials bytea, last_error text, unique (business_id, channel));
create table channel_permissions (connection_id uuid not null references channel_connections on delete cascade, business_id uuid not null references businesses on delete cascade, scope text not null, granted_at timestamptz not null default now(), primary key (connection_id, scope));

create table customers (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, name text not null, email text, phone text, opted_out boolean not null default false, created_at timestamptz not null default now());
create index on customers (business_id);
create table conversations (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, customer_id uuid references customers, channel text not null, assigned_agent text, status text not null default 'Open', priority text not null default 'Medium', next_action text, tags text[] not null default '{}', notes text[] not null default '{}', last_activity_at timestamptz not null default now());
create index on conversations (business_id, status, last_activity_at desc);
create table messages (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, conversation_id uuid not null references conversations on delete cascade, sender text not null, body text not null, delivery text, created_at timestamptz not null default now());
create index on messages (conversation_id, created_at);

create table leads (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, customer_id uuid references customers, name text not null, email text, phone text, company text, source text, channel text, requirement text, budget text, status text not null default 'New' check (status in ('New','Contacted','Qualified','Proposal','Negotiation','Won','Lost','Follow-up')), priority text not null default 'Medium', assigned_agent text, notes text, next_follow_up timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create index on leads (business_id, status);
create index on leads (business_id, next_follow_up);
create table tasks (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, title text not null, agent text, status text not null default 'Open', due_at timestamptz);
create table approvals (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, action text not null, tool text, requested_by text, agent text, summary text, risk text not null, state text not null default 'pending', decision_note text, decided_by uuid references users, created_at timestamptz not null default now(), decided_at timestamptz);
create index on approvals (business_id, state);
create table audit_events (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, at timestamptz not null default now(), user_label text, agent text, action text not null, tool text, channel text, approval_state text, result text not null, error text, detail text);
create index on audit_events (business_id, at desc);
create table automations (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, name text not null, trigger text, action text, agent text, enabled boolean not null default true);
create table notifications (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, user_id uuid references users, text text not null, read boolean not null default false, created_at timestamptz not null default now());
create table agent_runs (id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, agent text not null, input_summary text, output_summary text, status text not null, tokens_in int, tokens_out int, started_at timestamptz not null default now(), finished_at timestamptz);
create index on agent_runs (business_id, started_at desc);

-- Row-level security: every tenant table is readable/writable only by members of that business.
create or replace function is_member(b uuid, min_role member_role default 'viewer') returns boolean language sql stable security definer as $$
  select exists (select 1 from business_members m join users u on u.id = m.user_id
    where m.business_id = b and u.auth_user_id = auth.uid()
      and array_position(array['viewer','member','admin','owner']::member_role[], m.role) >= array_position(array['viewer','member','admin','owner']::member_role[], min_role));
$$;
do $$ declare t text; begin
  foreach t in array array['agents','agent_permissions','business_knowledge','knowledge_documents','knowledge_chunks','channel_connections','channel_permissions','customers','conversations','messages','leads','tasks','approvals','audit_events','automations','notifications','agent_runs'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy %I on %I for select using (is_member(business_id))', t || '_read', t);
    execute format('create policy %I on %I for all using (is_member(business_id, ''member'')) with check (is_member(business_id, ''member''))', t || '_write', t);
  end loop;
end $$;
-- Sensitive tables get stricter write rules.
drop policy approvals_write on approvals;
create policy approvals_decide on approvals for update using (is_member(business_id, 'owner'));
create policy approvals_insert on approvals for insert with check (is_member(business_id, 'member'));
drop policy channel_connections_write on channel_connections;
create policy channel_connections_admin on channel_connections for all using (is_member(business_id, 'admin')) with check (is_member(business_id, 'admin'));
-- audit_events is append-only for clients; the server (service role) writes it.
drop policy audit_events_write on audit_events;
alter table businesses enable row level security;
create policy businesses_read on businesses for select using (is_member(id));
create policy businesses_update on businesses for update using (is_member(id, 'admin'));
alter table business_members enable row level security;
create policy members_read on business_members for select using (is_member(business_id));
-- encrypted_credentials is never selectable by client roles; only the service role decrypts tokens, server-side.
revoke select (encrypted_credentials) on channel_connections from anon, authenticated;
