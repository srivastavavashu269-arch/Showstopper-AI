import { beforeEach, describe, expect, it } from 'vitest';
import { db, resetDb } from '@/lib/store';
import { authorizeTool, roleCan } from '@/lib/permissions';
import { decideRoute, executeApproved, routeTask } from '@/lib/manager';
import { retrieve } from '@/lib/knowledge';
import { redact, recordAudit } from '@/lib/audit';
import { getChannelProvider } from '@/lib/providers/channels/registry';
import { businessProfileSchema, leadSchema } from '@/lib/validation';

beforeEach(() => { resetDb(); });
const agent = (k: string) => db().agents.find(a => a.id === k)!;

describe('routing', () => {
  it.each([
    ['Can you share a quotation for the clinic?', 'sales'], ['Do you offer monthly maintenance?', 'support'],
    ['Run an Instagram campaign for our launch', 'marketing'], ['Redesign my website landing page', 'webdev'],
    ['Research local competitors', 'research'], ['Please follow up with the lead who did not respond', 'followup'],
  ])('%s -> %s', (text, expected) => { expect(decideRoute(text).agent).toBe(expected); });
  it('escalates sensitive wording', () => { expect(decideRoute('I want a refund').escalate).toBe(true); });
});

describe('authorization boundaries', () => {
  it('role gates', () => {
    expect(roleCan('viewer', 'view')).toBe(true); expect(roleCan('viewer', 'edit_leads')).toBe(false);
    expect(roleCan('admin', 'decide_approvals')).toBe(false); expect(roleCan('owner', 'decide_approvals')).toBe(true);
  });
  it('denies tools an agent does not have', () => { expect(authorizeTool(agent('research'), 'message.send_external').allowed).toBe(false); });
  it('always requires approval for external sends', () => {
    const d = authorizeTool(agent('sales'), 'message.send_external'); expect(d.allowed && d.needsApproval).toBe(true);
  });
  it('draft-only agents cannot publish', () => { expect(authorizeTool(agent('marketing'), 'content.publish').allowed).toBe(false); });
  it('disabled or paused agents are blocked', () => {
    agent('sales').enabled = false; expect(authorizeTool(agent('sales'), 'crm.write').allowed).toBe(false);
    agent('sales').enabled = true; agent('sales').status = 'paused'; expect(authorizeTool(agent('sales'), 'crm.write').allowed).toBe(false);
  });
});

describe('manager workflow', () => {
  it('creates an approval and sends nothing for a customer quotation request', async () => {
    const before = db().approvals.length;
    const r = await routeTask({ text: 'Please send me a quotation for a website', source: 'customer', channel: 'whatsapp', customerName: 'Test Customer', user: 'tester' });
    expect(r.routedTo).toBe('sales'); expect(r.output.status).toBe('awaiting_approval'); expect(db().approvals.length).toBe(before + 1);
    const conv = db().conversations.find(c => c.id === r.conversationId)!; expect(conv.messages.at(-1)?.delivery).toBe('draft');
  });
  it('approved send is NOT delivered when the channel is not connected', async () => {
    const r = await routeTask({ text: 'Please send me a quotation for a website', source: 'customer', channel: 'whatsapp', customerName: 'Test Customer', user: 'tester' });
    const ap = db().approvals.find(a => a.id === r.approvalId)!; ap.state = 'approved';
    const res = await executeApproved(ap, 'owner'); expect(res.ok).toBe(false); expect(res.message).toContain('not connected');
    expect(db().conversations.find(c => c.id === r.conversationId)!.messages.at(-1)?.delivery).toBe('blocked');
  });
  it('approved send is delivered once the demo channel is verified', async () => {
    const p = getChannelProvider('whatsapp'); await p.connect('+91 98765 43210'); await p.verifyConnection();
    const r = await routeTask({ text: 'Please send me a quotation for a website', source: 'customer', channel: 'whatsapp', customerName: 'Test Customer', user: 'tester' });
    const ap = db().approvals.find(a => a.id === r.approvalId)!; const res = await executeApproved(ap, 'owner'); expect(res.ok).toBe(true);
  });
  it('escalates sensitive requests and makes no commitment', async () => {
    const r = await routeTask({ text: 'I demand a refund and a discount', source: 'customer', channel: 'email', customerName: 'Angry', user: 't' });
    expect(r.output.status).toBe('escalated'); expect(r.approvalId).toBeTruthy();
  });
  it('support does not guess without approved knowledge', async () => {
    db().knowledge.forEach(k => (k.approved = false));
    const r = await routeTask({ text: 'Do you offer maintenance support?', source: 'customer', channel: 'website', customerName: 'V', user: 't' });
    expect(r.output.status).toBe('needs_information');
  });
  it('respects manager allowed-agent list', async () => {
    db().manager.allowedAgents = db().manager.allowedAgents.filter(a => a !== 'research');
    const r = await routeTask({ text: 'Research competitors', source: 'owner', user: 't' }); expect(r.output.status).toBe('blocked');
  });
});

describe('channels', () => {
  it('entering an identifier does not mean connected', async () => {
    const p = getChannelProvider('email'); const c = await p.connect('hello@example.com'); expect(c.status).toBe('pending');
    const v = await p.verifyConnection(); expect(v.status).toBe('connected'); expect(v.mode).toBe('demo');
  });
  it('rejects invalid identifiers and refuses to send when disconnected', async () => {
    const p = getChannelProvider('website'); expect((await p.connect('not a url')).status).toBe('error');
    expect((await getChannelProvider('instagram').sendMessage('x', 'hi')).ok).toBe(false);
  });
});

describe('knowledge, audit, validation', () => {
  it('retrieves only relevant approved context', () => {
    const r = retrieve('what is the refund policy'); expect(r[0]?.title).toBe('Refund policy'); expect(r.length).toBeLessThanOrEqual(3);
    db().knowledge.find(k => k.id === 'k4')!.approved = false; expect(retrieve('refund policy').find(c => c.id === 'k4')).toBeUndefined();
  });
  it('redacts secrets in audit entries', () => {
    expect(redact('failed with api_key=abc123xyz and Bearer abcdefghijkl')).not.toContain('abc123xyz');
    const e = recordAudit({ user: 'u', agent: null, action: 'x', tool: null, channel: null, approvalState: 'n/a', result: 'error', error: 'token: SECRET99' }); expect(e.error).not.toContain('SECRET99');
  });
  it('validates business profile and leads', () => {
    expect(businessProfileSchema.safeParse({ ...db().business, contactEmail: 'bad' }).success).toBe(false);
    expect(businessProfileSchema.safeParse(db().business).success).toBe(true);
    expect(leadSchema.safeParse({ name: 'A' }).success).toBe(false); expect(leadSchema.safeParse({ name: 'Alice Doe' }).success).toBe(true);
  });
});
