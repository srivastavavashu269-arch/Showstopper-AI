import { z } from 'zod';
import { LEAD_STATUSES } from './types';

export const businessProfileSchema = z.object({
  name: z.string().trim().min(2, 'Enter your business name').max(120),
  type: z.string().trim().min(2, 'Choose or enter a business type').max(80),
  description: z.string().trim().min(10, 'Describe your business in at least 10 characters').max(1000),
  location: z.string().trim().min(2, 'Enter a location').max(160),
  services: z.string().trim().min(2, 'List at least one service').max(1000),
  targetCustomers: z.string().trim().min(2, 'Describe your target customers').max(500),
  hours: z.string().trim().min(2, 'Enter business hours').max(200),
  contactEmail: z.string().trim().email('Enter a valid email address'),
  language: z.string().trim().min(2, 'Choose a language'),
  websiteUrl: z.string().trim().url('Enter a full URL, e.g. https://example.com').or(z.literal('')),
});
export const leadSchema = z.object({
  name: z.string().trim().min(2, 'Enter a name').max(120),
  email: z.string().trim().email('Enter a valid email').or(z.literal('')).default(''),
  phone: z.string().trim().max(40).default(''),
  company: z.string().trim().max(120).default(''),
  source: z.string().trim().max(80).default('Manual'),
  channel: z.enum(['whatsapp', 'email', 'instagram', 'website']).default('website'),
  requirement: z.string().trim().max(1000).default(''),
  budget: z.string().trim().max(80).default(''),
  status: z.enum(LEAD_STATUSES as [string, ...string[]]).default('New'),
  priority: z.enum(['Low', 'Medium', 'High', 'Urgent']).default('Medium'),
  assignedAgent: z.enum(['sales', 'followup', 'support', 'marketing', 'webdev', 'research', 'manager']).default('sales'),
  notes: z.string().max(4000).default(''),
  nextFollowUp: z.string().nullable().default(null),
});
export const leadPatchSchema = leadSchema.partial();
export const approvalDecisionSchema = z.object({
  decision: z.enum(['approve', 'reject', 'request_changes']),
  note: z.string().trim().max(1000).optional(),
});
export const routeTaskSchema = z.object({
  text: z.string().trim().min(2, 'Enter a task or message').max(2000),
  channel: z.enum(['whatsapp', 'email', 'instagram', 'website']).optional(),
  source: z.enum(['customer', 'owner']).default('owner'),
  customerName: z.string().trim().max(120).optional(),
});
export const agentPatchSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  description: z.string().trim().max(500).optional(),
  instructions: z.string().trim().max(4000).optional(),
  enabled: z.boolean().optional(),
  allowedTools: z.array(z.string()).optional(),
  permissionLevel: z.enum(['read_only', 'draft_only', 'act_with_approval', 'act_autonomously']).optional(),
  requiresApproval: z.boolean().optional(),
  status: z.enum(['idle', 'working', 'paused', 'needs_attention']).optional(),
});
export const managerPatchSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  instructions: z.string().trim().min(10).max(6000).optional(),
  routingStrategy: z.enum(['rules', 'ai_assisted', 'hybrid']).optional(),
  approvalMode: z.enum(['strict', 'balanced', 'relaxed']).optional(),
  escalationRules: z.string().max(2000).optional(),
  allowedAgents: z.array(z.string()).optional(),
  allowedTools: z.array(z.string()).optional(),
});
export const knowledgeSchema = z.object({
  category: z.enum(['Business', 'Services', 'Pricing', 'FAQs', 'Policies', 'Brand Voice', 'Internal Instructions', 'Documents']),
  title: z.string().trim().min(2, 'Enter a title').max(160),
  content: z.string().trim().min(5, 'Add some content').max(8000),
});
export const conversationPatchSchema = z.object({
  status: z.enum(['Open', 'Waiting', 'Resolved', 'Escalated']).optional(),
  priority: z.enum(['Low', 'Medium', 'High', 'Urgent']).optional(),
  assignedAgent: z.enum(['sales', 'followup', 'support', 'marketing', 'webdev', 'research', 'manager']).optional(),
  addNote: z.string().trim().max(1000).optional(),
  addTag: z.string().trim().max(40).optional(),
  nextAction: z.string().trim().max(200).optional(),
});
