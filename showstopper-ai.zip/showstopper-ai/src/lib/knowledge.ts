import { db } from './store';
import type { KnowledgeItem } from './types';

const STOP = new Set(['the', 'a', 'an', 'and', 'or', 'to', 'of', 'for', 'is', 'are', 'do', 'you', 'i', 'we', 'my', 'me', 'can', 'in', 'on', 'it', 'your', 'how', 'what', 'with']);
const tokens = (s: string) => s.toLowerCase().split(/\W+/).filter(w => w.length > 2 && !STOP.has(w));

export interface RetrievedChunk { id: string; title: string; category: string; text: string; score: number; source: string }

/** Level 1 lexical retrieval behind the same interface a vector search (pgvector + embeddings) will use in Level 2. Only approved items are searchable. */
export function retrieve(query: string, k = 3, categories?: KnowledgeItem['category'][]): RetrievedChunk[] {
  const q = new Set(tokens(query));
  if (q.size === 0) return [];
  return db().knowledge
    .filter(i => i.approved && (!categories || categories.includes(i.category)))
    .map(i => {
      const t = tokens(i.title + ' ' + i.content); let hit = 0;
      for (const w of t) if (q.has(w)) hit += 1;
      const titleHit = tokens(i.title).filter(w => q.has(w)).length * 2;
      return { id: i.id, title: i.title, category: i.category, text: i.content, source: `${i.category}: ${i.title}`, score: (hit + titleHit) / Math.sqrt(t.length || 1) };
    })
    .filter(c => c.score > 0.2).sort((a, b) => b.score - a.score).slice(0, k);
}
