export interface ChatMessage { role: 'system' | 'user' | 'assistant' | 'tool'; content: string }
export interface StructuredResult<T> { data: T; provider: string }

/** Provider-agnostic AI contract. Concrete adapters (NVIDIA NIM, others) live next to this file. */
export interface AIProvider {
  readonly name: string;
  chat(messages: ChatMessage[], opts?: { json?: boolean }): Promise<string>;
  embed(texts: string[]): Promise<number[][]>;
}

/** Deterministic local provider used in Level 1. No network, no keys. */
export class MockAIProvider implements AIProvider {
  readonly name = 'mock';
  async chat(messages: ChatMessage[]): Promise<string> {
    const last = messages[messages.length - 1]?.content ?? '';
    return `[demo draft] ${last.slice(0, 280)}`;
  }
  async embed(texts: string[]): Promise<number[][]> {
    return texts.map(t => { const v = new Array(16).fill(0); for (const w of t.toLowerCase().split(/\W+/)) { let h = 0; for (const ch of w) h = (h * 31 + ch.charCodeAt(0)) % 16; v[h] += 1; } return v; });
  }
}

/** NVIDIA NIM exposes an OpenAI-compatible API. Server-side only; key comes from env and is never sent to prompts or clients. */
export class NimProvider implements AIProvider {
  readonly name = 'nvidia-nim';
  constructor(private baseUrl: string, private apiKey: string, private chatModel: string, private embedModel: string) {}
  async chat(messages: ChatMessage[], opts?: { json?: boolean }): Promise<string> {
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify({ model: this.chatModel, messages, ...(opts?.json ? { response_format: { type: 'json_object' } } : {}) }),
    });
    if (!res.ok) throw new Error(`AI provider error ${res.status}`);
    const j = await res.json(); return j.choices?.[0]?.message?.content ?? '';
  }
  async embed(texts: string[]): Promise<number[][]> {
    const res = await fetch(`${this.baseUrl}/embeddings`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify({ model: this.embedModel, input: texts }),
    });
    if (!res.ok) throw new Error(`Embedding provider error ${res.status}`);
    const j = await res.json(); return j.data.map((d: { embedding: number[] }) => d.embedding);
  }
}

export function getAIProvider(): AIProvider {
  const p = process.env.AI_PROVIDER;
  if (p === 'nvidia-nim' && process.env.NVIDIA_NIM_API_KEY && process.env.AI_CHAT_MODEL) {
    return new NimProvider(process.env.NVIDIA_NIM_BASE_URL ?? 'https://integrate.api.nvidia.com/v1', process.env.NVIDIA_NIM_API_KEY, process.env.AI_CHAT_MODEL, process.env.AI_EMBEDDING_MODEL ?? '');
  }
  return new MockAIProvider();
}
