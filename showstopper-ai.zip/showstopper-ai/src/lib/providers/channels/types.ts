import type { ChannelId, Connection } from '../../types';

export interface SendResult { ok: boolean; messageId?: string; error?: string }
export interface InboundEvent { channel: ChannelId; customerName: string; text: string }

/** Every channel (demo or live) implements this contract. Core logic never imports a concrete provider. */
export interface ChannelProvider {
  readonly channel: ChannelId;
  readonly mode: 'demo' | 'live';
  connect(identifier: string): Promise<Connection>;
  disconnect(): Promise<Connection>;
  getStatus(): Promise<Connection>;
  verifyConnection(): Promise<Connection>;
  receiveEvent(raw: unknown): Promise<InboundEvent | null>;
  sendMessage(to: string, text: string): Promise<SendResult>;
  listPermissions(): Promise<string[]>;
}
