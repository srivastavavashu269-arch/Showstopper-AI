import { db } from '../../store';
import type { ChannelId, Connection } from '../../types';
import type { ChannelProvider, InboundEvent, SendResult } from './types';

const PERMS: Record<ChannelId, string[]> = {
  whatsapp: ['Read inbound messages', 'Send template replies', 'Read delivery status'],
  email: ['Read inbox', 'Create drafts', 'Send email'],
  instagram: ['Read direct messages', 'Reply to messages', 'Read insights'],
  website: ['Analyze public pages', 'Receive chat widget messages'],
};
const LABEL: Record<ChannelId, string> = { whatsapp: 'WhatsApp number', email: 'email address', instagram: 'Instagram username', website: 'website URL' };

function validate(channel: ChannelId, id: string): string | null {
  const v = id.trim();
  if (!v) return `Enter a ${LABEL[channel]}`;
  if (channel === 'whatsapp' && !/^\+?[0-9 ()-]{8,18}$/.test(v)) return 'Enter a valid phone number with country code';
  if (channel === 'email' && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) return 'Enter a valid email address';
  if (channel === 'instagram' && !/^@?[A-Za-z0-9._]{2,30}$/.test(v)) return 'Enter a valid Instagram username';
  if (channel === 'website' && !/^https?:\/\/[^\s.]+\.[^\s]+$/.test(v)) return 'Enter a full URL, e.g. https://example.com';
  return null;
}

/**
 * Demo provider: simulates the authorize-then-verify handshake locally.
 * Entering an identifier only moves the channel to "pending". It becomes "connected" solely after verifyConnection().
 * Connections are always labelled mode "demo"; nothing is ever sent to a real network.
 */
export class MockChannelProvider implements ChannelProvider {
  readonly mode = 'demo' as const;
  constructor(readonly channel: ChannelId) {}
  private conn(): Connection { return db().connections.find(c => c.channel === this.channel)!; }
  async connect(identifier: string): Promise<Connection> {
    const c = this.conn(); const err = validate(this.channel, identifier);
    if (err) { c.status = 'error'; c.lastError = err; return { ...c }; }
    c.identifier = identifier.trim(); c.status = 'pending'; c.lastError = undefined; c.verifiedAt = null; c.mode = 'demo';
    return { ...c };
  }
  async verifyConnection(): Promise<Connection> {
    const c = this.conn();
    if (c.status === 'disconnected' || !c.identifier) { c.lastError = 'Start the connection first'; c.status = 'error'; return { ...c }; }
    c.status = 'connected'; c.verifiedAt = new Date().toISOString(); c.permissions = PERMS[this.channel]; c.lastError = undefined;
    return { ...c };
  }
  async disconnect(): Promise<Connection> {
    const c = this.conn(); c.status = 'disconnected'; c.identifier = ''; c.verifiedAt = null; c.permissions = []; c.lastError = undefined;
    return { ...c };
  }
  async getStatus(): Promise<Connection> { return { ...this.conn() }; }
  async listPermissions(): Promise<string[]> { return PERMS[this.channel]; }
  async receiveEvent(raw: unknown): Promise<InboundEvent | null> {
    const r = raw as { customerName?: string; text?: string };
    if (!r?.text) return null;
    return { channel: this.channel, customerName: r.customerName ?? 'Unknown customer', text: r.text };
  }
  async sendMessage(_to: string, text: string): Promise<SendResult> {
    const c = this.conn();
    if (c.status !== 'connected') return { ok: false, error: `${this.channel} is not connected, so nothing was sent` };
    if (!text.trim()) return { ok: false, error: 'Message is empty' };
    return { ok: true, messageId: `demo_${Date.now()}` };
  }
}
export const channelPermissionOptions = PERMS;
