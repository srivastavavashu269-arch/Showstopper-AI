import type { ChannelId } from '../../types';
import type { ChannelProvider } from './types';
import { MockChannelProvider } from './mock';

/** Level 2/3: return real adapters (WhatsApp Cloud API, Gmail OAuth, Meta, site connectors) when APP_MODE=live and credentials exist. */
export function getChannelProvider(channel: ChannelId): ChannelProvider {
  return new MockChannelProvider(channel);
}
export const CHANNELS: ChannelId[] = ['whatsapp', 'email', 'instagram', 'website'];
