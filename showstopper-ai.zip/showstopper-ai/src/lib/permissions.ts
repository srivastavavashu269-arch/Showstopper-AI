import type { Agent, AgentKey, ManagerConfig, PermissionLevel, Role, ToolId } from './types';

const ROLE_RANK: Record<Role, number> = { viewer: 0, member: 1, admin: 2, owner: 3 };
export type AppPermission =
  | 'view' | 'edit_leads' | 'edit_agents' | 'edit_manager' | 'decide_approvals'
  | 'manage_connections' | 'edit_settings' | 'run_tasks' | 'edit_knowledge';

const REQUIRED_ROLE: Record<AppPermission, Role> = {
  view: 'viewer', edit_leads: 'member', run_tasks: 'member', edit_knowledge: 'admin', edit_agents: 'admin',
  manage_connections: 'admin', edit_settings: 'admin', edit_manager: 'owner', decide_approvals: 'owner',
};
export function roleCan(role: Role, p: AppPermission): boolean { return ROLE_RANK[role] >= ROLE_RANK[REQUIRED_ROLE[p]]; }

/** Tools that always need human approval before execution, regardless of agent settings. */
export const ALWAYS_APPROVE: ToolId[] = ['message.send_external', 'content.publish', 'quote.publish', 'website.deploy'];
export const TOOL_RISK: Record<ToolId, 'Low' | 'Medium' | 'High'> = {
  'crm.read': 'Low', 'crm.write': 'Low', 'conversation.reply': 'Medium', 'message.send_external': 'High', 'task.create': 'Low',
  'followup.schedule': 'Low', 'content.draft': 'Low', 'content.publish': 'High', 'faq.read': 'Low', 'ticket.create': 'Low',
  'research.run': 'Low', 'project.plan': 'Low', 'website.deploy': 'High', 'quote.publish': 'High', 'workflow.trigger': 'Medium',
};
export const TOOL_LABEL: Record<ToolId, string> = {
  'crm.read': 'Read CRM', 'crm.write': 'Write CRM', 'conversation.reply': 'Reply in conversation', 'message.send_external': 'Send external message',
  'task.create': 'Create task', 'followup.schedule': 'Schedule follow-up', 'content.draft': 'Draft content', 'content.publish': 'Publish content',
  'faq.read': 'Read FAQs', 'ticket.create': 'Create ticket', 'research.run': 'Run research', 'project.plan': 'Plan project',
  'website.deploy': 'Deploy website', 'quote.publish': 'Publish quotation', 'workflow.trigger': 'Trigger workflow',
};

export type ToolDecision =
  | { allowed: true; needsApproval: boolean; reason: string }
  | { allowed: false; reason: string };

/** Single backend gate every agent tool call must pass through. */
export function authorizeTool(agent: Agent, tool: ToolId, manager?: ManagerConfig): ToolDecision {
  if (!agent.enabled) return { allowed: false, reason: `${agent.name} is disabled` };
  if (agent.status === 'paused') return { allowed: false, reason: `${agent.name} is paused` };
  if (!agent.allowedTools.includes(tool)) return { allowed: false, reason: `${agent.name} is not allowed to use ${TOOL_LABEL[tool]}` };
  const level: PermissionLevel = agent.permissionLevel;
  const writes = !['crm.read', 'faq.read'].includes(tool);
  if (level === 'read_only' && writes) return { allowed: false, reason: 'Agent has read-only permission' };
  if (level === 'draft_only' && ['message.send_external', 'content.publish', 'quote.publish', 'website.deploy'].includes(tool))
    return { allowed: false, reason: 'Agent can only draft; it cannot execute this action' };
  let needs = ALWAYS_APPROVE.includes(tool) || agent.requiresApproval && TOOL_RISK[tool] !== 'Low' || level === 'act_with_approval' && writes && TOOL_RISK[tool] !== 'Low';
  if (manager?.approvalMode === 'strict' && TOOL_RISK[tool] !== 'Low') needs = true;
  return { allowed: true, needsApproval: needs, reason: needs ? 'Owner approval required' : 'Permitted' };
}
export function agentAllowedByManager(manager: ManagerConfig, key: AgentKey) { return manager.allowedAgents.includes(key); }
