/**
 * Level 1 in-memory repository. All access goes through this module so Level 2 can swap in
 * a Postgres/Supabase implementation without touching services or UI.
 */
import type { Agent, Approval, AuditEvent, Automation, Business, Connection, Conversation, KnowledgeItem, Lead, ManagerConfig, Notification, Task } from './types';
import * as D from './demo-data';

export interface DB {
  business: Business; manager: ManagerConfig; agents: Agent[]; knowledge: KnowledgeItem[]; leads: Lead[];
  conversations: Conversation[]; approvals: Approval[]; tasks: Task[]; connections: Connection[]; automations: Automation[];
  audit: AuditEvent[]; notifications: Notification[]; seq: number;
}
function seed(): DB {
  return { business: D.makeBusiness(), manager: D.makeManager(), agents: D.makeAgents(), knowledge: D.makeKnowledge(), leads: D.makeLeads(),
    conversations: D.makeConversations(), approvals: D.makeApprovals(), tasks: D.makeTasks(), connections: D.makeConnections(),
    automations: D.makeAutomations(), audit: D.makeAudit(), notifications: [], seq: 100 };
}
const g = globalThis as unknown as { __ssdb?: DB };
export function db(): DB { if (!g.__ssdb) g.__ssdb = seed(); return g.__ssdb; }
export function resetDb() { g.__ssdb = seed(); return g.__ssdb; }
export function nextId(prefix: string) { const d = db(); d.seq += 1; return `${prefix}_${d.seq}`; }
