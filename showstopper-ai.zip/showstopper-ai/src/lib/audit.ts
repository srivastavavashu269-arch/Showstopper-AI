import { db, nextId } from './store';
import type { AuditEvent } from './types';

const SECRET_PATTERN = /(sk-[A-Za-z0-9_-]{8,}|Bearer\s+[A-Za-z0-9._-]{8,}|(api[_-]?key|token|secret|password)\s*[:=]\s*\S+)/gi;
export function redact(text?: string): string | undefined { return text?.replace(SECRET_PATTERN, '[redacted]'); }

export function recordAudit(e: Omit<AuditEvent, 'id' | 'at' | 'business'> & { at?: string }): AuditEvent {
  const d = db();
  const ev: AuditEvent = { ...e, id: nextId('ae'), at: e.at ?? new Date().toISOString(), business: d.business.name, error: redact(e.error), detail: redact(e.detail) };
  d.audit.unshift(ev);
  if (d.audit.length > 500) d.audit.length = 500;
  return ev;
}
