import type { Agent, Approval, Automation, Business, Connection, Conversation, KnowledgeItem, Lead, ManagerConfig, Task, ToolId, AuditEvent } from './types';

const ago = (min: number) => new Date(Date.now() - min * 60000).toISOString();
const ahead = (hrs: number) => new Date(Date.now() + hrs * 3600000).toISOString();

export const MANAGER_DEFAULT_INSTRUCTIONS = `You are the Central AI Manager for AI Showstopper.

Coordinate all specialist AI agents.

Understand incoming tasks.

Select the correct specialist.

Provide only the required business context.

Respect permissions.

Never bypass owner approval.

If information is missing, ask for it.

If an action is sensitive, escalate it.

Never claim an external action succeeded unless the backend confirms success.

Record task activity in the audit system.`;

const T = (...t: ToolId[]) => t;
export function makeAgents(): Agent[] {
  const base = { enabled: true, status: 'idle' as const, lastActivity: ago(12) };
  return [
    { ...base, id: 'sales', name: 'Sales & Lead Agent', role: 'Qualifies leads and drafts proposals', description: 'Owns inbound lead handling and sales qualification across all channels.',
      instructions: 'Gather goal, service, timeline, budget and contact details. Create or update the CRM record. Never approve discounts, promise prices or create binding contracts. Draft quotations for owner approval.',
      allowedTools: T('crm.read', 'crm.write', 'conversation.reply', 'task.create', 'followup.schedule', 'quote.publish', 'message.send_external'), permissionLevel: 'act_with_approval', requiresApproval: true },
    { ...base, id: 'marketing', name: 'Marketing Agent', role: 'Plans campaigns and drafts content', description: 'Creates campaign concepts, captions, reel ideas and content calendars.',
      instructions: 'Match the approved brand voice and offers. Do not make unapproved claims or expose customer data. Publishing needs owner approval.',
      allowedTools: T('content.draft', 'content.publish', 'task.create', 'crm.read'), permissionLevel: 'draft_only', requiresApproval: true },
    { ...base, id: 'support', name: 'Customer Support Agent', role: 'Answers questions from approved knowledge', description: 'Handles FAQs, classifies issues and escalates anything outside the rules.',
      instructions: 'Use approved knowledge only. Never invent policies or pricing. Escalate refunds, complaints and legal threats.',
      allowedTools: T('faq.read', 'conversation.reply', 'ticket.create', 'crm.read'), permissionLevel: 'act_with_approval', requiresApproval: false },
    { ...base, id: 'webdev', name: 'Web Development Agent', role: 'Plans website work and tracks scope', description: 'Turns approved requirements into technical tasks, plans and QA checklists.',
      instructions: 'Work only within approved scope. A URL alone is not admin access. Production deployment requires authorization.',
      allowedTools: T('project.plan', 'task.create', 'crm.read', 'website.deploy'), permissionLevel: 'draft_only', requiresApproval: true },
    { ...base, id: 'research', name: 'Research Agent', role: 'Researches markets and competitors', description: 'Summarises findings and separates facts, assumptions and recommendations.',
      instructions: 'Cite sources. Label every statement as fact, assumption or recommendation. Do not make final business decisions.',
      allowedTools: T('research.run', 'task.create'), permissionLevel: 'act_with_approval', requiresApproval: false },
    { ...base, id: 'followup', name: 'Follow-up Agent', role: 'Keeps leads moving', description: 'Schedules follow-ups and drafts polite, context-aware messages.',
      instructions: 'Honour opt-outs and do-not-contact. Avoid excessive contact. Escalate high-value follow-ups.',
      allowedTools: T('crm.read', 'crm.write', 'followup.schedule', 'message.send_external', 'task.create'), permissionLevel: 'act_with_approval', requiresApproval: true },
  ];
}
export function makeManager(): ManagerConfig {
  return { name: 'AI Showstopper Manager', instructions: MANAGER_DEFAULT_INSTRUCTIONS, routingStrategy: 'hybrid', approvalMode: 'balanced',
    escalationRules: 'Escalate to the owner for pricing changes, discounts, refunds, legal threats, complaints and any external commitment.',
    allowedAgents: ['sales', 'marketing', 'support', 'webdev', 'research', 'followup'],
    allowedTools: T('crm.read', 'task.create', 'workflow.trigger') };
}
export function makeBusiness(): Business {
  return { id: 'biz_demo', name: 'Brightline Studio', type: 'Digital agency', description: 'Boutique studio building websites and brand campaigns for local businesses.',
    location: 'Lucknow, India', services: 'Website design, SEO, social media campaigns, brand identity', targetCustomers: 'Local retailers, clinics and restaurants',
    hours: 'Mon–Sat, 10:00–19:00 IST', contactEmail: 'hello@brightline.example', language: 'English', websiteUrl: 'https://brightline.example', onboardingStep: 0, onboardingComplete: false };
}
export function makeKnowledge(): KnowledgeItem[] {
  const k = (id: string, category: KnowledgeItem['category'], title: string, content: string, approved = true): KnowledgeItem =>
    ({ id, category, title, content, approved, source: 'owner', updatedAt: ago(600) });
  return [
    k('k1', 'Services', 'Website design', 'We design and build responsive business websites. Typical delivery is 3 to 5 weeks depending on scope.'),
    k('k2', 'Pricing', 'Website packages', 'Starter website packages begin at INR 40,000. Custom quotes are prepared by the owner after a requirements call.'),
    k('k3', 'FAQs', 'Do you offer maintenance?', 'Yes. Monthly maintenance plans cover updates, backups and small content changes.'),
    k('k4', 'Policies', 'Refund policy', 'Deposits are non-refundable once design work has started. Refund exceptions are decided by the owner.'),
    k('k5', 'Brand Voice', 'Tone', 'Friendly, clear and professional. Avoid jargon and never overpromise.'),
    k('k6', 'Business', 'Working hours', 'Open Monday to Saturday, 10:00 to 19:00 IST. Closed Sundays.'),
    k('k7', 'FAQs', 'How do I start a project?', 'Share your goals and budget range. We schedule a free 30 minute requirements call.'),
    k('k8', 'Internal Instructions', 'Discount rule', 'Agents must never offer discounts. All discount requests go to the owner.', true),
  ];
}
export function makeLeads(): Lead[] {
  const l = (id: string, name: string, company: string, channel: Lead['channel'], req: string, budget: string, status: Lead['status'], pr: Lead['priority'], agent: Lead['assignedAgent'], fu: number | null, createdMin: number): Lead =>
    ({ id, name, email: name.toLowerCase().replace(/[^a-z]/g, '.') + '@example.com', phone: '+91 98' + (10000000 + Math.abs(id.length * 7391 + createdMin) % 89999999), company, source: channel === 'website' ? 'Website chat' : channel, channel, requirement: req, budget, status, priority: pr, assignedAgent: agent, notes: '', nextFollowUp: fu === null ? null : ahead(fu), createdAt: ago(createdMin), updatedAt: ago(Math.max(5, createdMin / 3)) });
  return [
    l('l1', 'Aarav Mehta', 'Mehta Sweets', 'whatsapp', 'New website with online ordering', 'INR 80,000', 'Qualified', 'High', 'sales', 20, 300),
    l('l2', 'Sana Qureshi', 'Qureshi Dental Clinic', 'email', 'Redesign clinic website and booking page', 'INR 60,000', 'Proposal', 'High', 'sales', 48, 2000),
    l('l3', 'Rohan Gupta', 'Gupta Fitness', 'instagram', 'Instagram campaign for new branch', 'INR 25,000', 'New', 'Medium', 'marketing', null, 90),
    l('l4', 'Neha Verma', 'Verma Boutique', 'website', 'SEO and product pages', 'INR 30,000', 'Contacted', 'Medium', 'sales', 6, 1400),
    l('l5', 'Imran Ali', 'Ali Traders', 'whatsapp', 'Catalogue website', 'Not shared', 'Follow-up', 'Low', 'followup', 2, 4200),
    l('l6', 'Priya Nair', 'Nair Cafe', 'email', 'Brand identity and menu design', 'INR 45,000', 'Negotiation', 'High', 'sales', 24, 6000),
    l('l7', 'Kabir Singh', 'Singh Motors', 'website', 'Lead capture landing page', 'INR 15,000', 'Won', 'Medium', 'webdev', null, 9000),
    l('l8', 'Tara Joshi', 'Joshi Events', 'instagram', 'Reel campaign', 'INR 20,000', 'Lost', 'Low', 'marketing', null, 12000),
  ];
}
export function makeConversations(): Conversation[] {
  const c = (id: string, cust: string, channel: Conversation['channel'], agent: Conversation['assignedAgent'], status: Conversation['status'], pr: Conversation['priority'], next: string, msgs: [string, string][], minAgo: number): Conversation => ({
    id, customerId: 'cu_' + id, customerName: cust, channel, assignedAgent: agent, status, priority: pr, lastActivity: ago(minAgo), nextAction: next, tags: [], notes: [],
    messages: msgs.map(([from, text], i) => ({ id: `${id}_m${i}`, conversationId: id, from: from as 'customer' | 'agent', text, at: ago(minAgo + (msgs.length - i) * 3), delivery: from === 'agent' ? 'sent' : undefined })) });
  return [
    c('c1', 'Aarav Mehta', 'whatsapp', 'sales', 'Open', 'High', 'Prepare quotation draft for approval', [['customer', 'Hi, I need a website with online ordering for my sweet shop.'], ['agent', 'Happy to help! What is your approximate budget and timeline?'], ['customer', 'Around 80k, and we want to launch before Diwali.']], 8),
    c('c2', 'Sana Qureshi', 'email', 'sales', 'Waiting', 'High', 'Awaiting owner approval on quotation', [['customer', 'Can you share the quotation for the clinic website?'], ['agent', 'I have prepared a draft and sent it to the owner for review.']], 55),
    c('c3', 'Walk-in visitor', 'website', 'support', 'Open', 'Low', 'Answer with approved FAQ', [['customer', 'Do you offer monthly maintenance for websites?']], 3),
    c('c4', 'Rohan Gupta', 'instagram', 'marketing', 'Open', 'Medium', 'Draft campaign concept', [['customer', 'We are opening a new gym branch. Can you run a launch campaign?']], 40),
    c('c5', 'Imran Ali', 'whatsapp', 'followup', 'Waiting', 'Low', 'Follow-up due in 2 hours', [['agent', 'Hi Imran, just checking in on the catalogue website. Any questions?']], 1500),
    c('c6', 'Meera Das', 'email', 'support', 'Escalated', 'Urgent', 'Owner to review refund request', [['customer', 'I want a refund for the deposit. The design was not what I expected.']], 25),
  ];
}
export function makeApprovals(): Approval[] {
  return [
    { id: 'a1', action: 'Publish quotation', requestedBy: 'Sales & Lead Agent', agent: 'sales', business: 'Brightline Studio', summary: 'Quotation of INR 62,000 for the Qureshi Dental Clinic website redesign.', date: ago(50), risk: 'High', state: 'pending', tool: 'quote.publish' },
    { id: 'a2', action: 'Send external message', requestedBy: 'Follow-up Agent', agent: 'followup', business: 'Brightline Studio', summary: 'Follow-up message to Imran Ali about the catalogue website.', date: ago(35), risk: 'Medium', state: 'pending', tool: 'message.send_external' },
    { id: 'a3', action: 'Publish campaign', requestedBy: 'Marketing Agent', agent: 'marketing', business: 'Brightline Studio', summary: 'Instagram launch carousel for Gupta Fitness (3 posts, 1 reel).', date: ago(120), risk: 'High', state: 'pending', tool: 'content.publish' },
    { id: 'a4', action: 'Production website deployment', requestedBy: 'Web Development Agent', agent: 'webdev', business: 'Brightline Studio', summary: 'Deploy Singh Motors landing page to production.', date: ago(300), risk: 'High', state: 'approved', tool: 'website.deploy' },
  ];
}
export function makeTasks(): Task[] {
  return [
    { id: 't1', title: 'Draft quotation for Mehta Sweets', agent: 'sales', status: 'In progress', due: ahead(4) },
    { id: 't2', title: 'Plan Gupta Fitness launch calendar', agent: 'marketing', status: 'Open', due: ahead(24) },
    { id: 't3', title: 'Competitor review: local web agencies', agent: 'research', status: 'Open', due: ahead(48) },
    { id: 't4', title: 'QA checklist for Singh Motors page', agent: 'webdev', status: 'Done', due: null },
    { id: 't5', title: 'Follow up with Verma Boutique', agent: 'followup', status: 'Open', due: ahead(6) },
  ];
}
export function makeConnections(): Connection[] {
  return (['whatsapp', 'email', 'instagram', 'website'] as const).map(channel => ({ channel, status: 'disconnected', mode: 'demo', identifier: '', verifiedAt: null, permissions: [] }));
}
export function makeAutomations(): Automation[] {
  return [
    { id: 'au1', name: 'No-reply nudge', trigger: 'Lead has no reply for 48 hours', action: 'Follow-up Agent drafts a reminder for approval', agent: 'followup', enabled: true },
    { id: 'au2', name: 'New lead qualification', trigger: 'New inbound sales inquiry', action: 'Sales Agent qualifies and creates CRM record', agent: 'sales', enabled: true },
    { id: 'au3', name: 'FAQ auto-answer', trigger: 'Inbound question matches approved FAQ', action: 'Support Agent drafts an answer', agent: 'support', enabled: true },
    { id: 'au4', name: 'Weekly content plan', trigger: 'Every Monday 09:00', action: 'Marketing Agent drafts the weekly calendar', agent: 'marketing', enabled: false },
  ];
}
export function makeAudit(): AuditEvent[] {
  return [
    { id: 'ae1', at: ago(50), business: 'Brightline Studio', user: 'system', agent: 'sales', action: 'Quotation drafted', tool: 'quote.publish', channel: 'email', approvalState: 'pending', result: 'pending' },
    { id: 'ae2', at: ago(300), business: 'Brightline Studio', user: 'owner@brightline.example', agent: 'webdev', action: 'Deployment approved', tool: 'website.deploy', channel: null, approvalState: 'approved', result: 'success' },
  ];
}
