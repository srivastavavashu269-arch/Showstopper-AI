import { db, nextId } from './store';
import { recordAudit } from './audit';
import { authorizeTool, agentAllowedByManager, TOOL_LABEL, TOOL_RISK } from './permissions';
import { retrieve } from './knowledge';
import { getAIProvider } from './providers/ai';
import { getChannelProvider } from './providers/channels/registry';
import type { Agent, AgentKey, Approval, ChannelId, Conversation, ToolId } from './types';

const RULES: { agent: AgentKey; tool: ToolId; words: RegExp; label: string }[] = [
  { agent: 'support', tool: 'faq.read', label: 'Common question', words: /\b(refund|complain|faq|hours?|open|policy|maintenance|support|how do i|do you offer|help with)\b/i },
  { agent: 'sales', tool: 'quote.publish', label: 'Quotation request', words: /\b(quot(e|ation)|price|pricing|cost|proposal|budget|estimate|discount)\b/i },
  { agent: 'marketing', tool: 'content.draft', label: 'Marketing request', words: /\b(campaign|instagram post|caption|reel|content calendar|promo|social media|ad copy)\b/i },
  { agent: 'webdev', tool: 'project.plan', label: 'Website work', words: /\b(website|web ?site|landing page|redesign|seo|bug|deploy|page speed|new site)\b/i },
  { agent: 'research', tool: 'research.run', label: 'Research request', words: /\b(research|competitor|market|compare|trend|analy[sz]e)\b/i },
  { agent: 'followup', tool: 'followup.schedule', label: 'Follow-up', words: /\b(follow[- ]?up|remind|no response|check in|nudge)\b/i },
  { agent: 'sales', tool: 'crm.write', label: 'Sales inquiry', words: /\b(need|looking for|interested|buy|hire|build|service)\b/i },
];

export interface RouteDecision { agent: AgentKey; tool: ToolId; reason: string; escalate: boolean; matchedRule: string }

/** Pure routing decision (testable). Sensitive wording is escalated to the owner via the manager. */
export function decideRoute(text: string): RouteDecision {
  const sensitive = /\b(refund|legal|lawyer|sue|chargeback|discount|compensation|complaint)\b/i.test(text);
  const hit = RULES.find(r => r.words.test(text));
  if (!hit) return { agent: 'sales', tool: 'crm.write', reason: 'No specific match; defaulting to Sales for triage', escalate: sensitive, matchedRule: 'default' };
  return { agent: hit.agent, tool: hit.tool, reason: `${hit.label} routed to ${hit.agent}`, escalate: sensitive, matchedRule: hit.label };
}

export interface AgentOutput { task: string; result: string; status: 'completed' | 'awaiting_approval' | 'blocked' | 'needs_information' | 'escalated'; blockers: string[]; nextAction: string }
export interface RouteOutcome { routedTo: AgentKey; agentName: string; reason: string; output: AgentOutput; approvalId?: string; conversationId?: string; knowledge: { source: string; score: number }[] }

function getAgent(key: AgentKey): Agent { return db().agents.find(a => a.id === key)!; }

export async function routeTask(input: { text: string; channel?: ChannelId; source: 'customer' | 'owner'; customerName?: string; user: string }): Promise<RouteOutcome> {
  const d = db();
  const decision = decideRoute(input.text);
  let agent = getAgent(decision.agent);
  const base = { user: input.user, channel: input.channel ?? null };

  // Manager-level gate: the agent must be permitted by the manager config.
  if (!agentAllowedByManager(d.manager, agent.id)) {
    recordAudit({ ...base, agent: agent.id, action: 'Routing blocked by manager config', tool: decision.tool, approvalState: 'n/a', result: 'blocked', error: 'Agent not in manager allowed list' });
    return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge: [], output: { task: input.text, result: `${agent.name} is not allowed by the Central AI Manager settings.`, status: 'blocked', blockers: ['Agent not allowed'], nextAction: 'Owner can allow this agent in Manager settings' } };
  }
  d.agents.find(a => a.id === agent.id)!.lastActivity = new Date().toISOString();

  const conv = input.source === 'customer' ? upsertConversation(input, agent.id) : undefined;
  const chunks = retrieve(input.text, 3);
  const knowledge = chunks.map(c => ({ source: c.source, score: Math.round(c.score * 100) / 100 }));

  // Customer-facing support must rely on approved knowledge only.
  if (agent.id === 'support' && chunks.length === 0 && !decision.escalate) {
    recordAudit({ ...base, agent: agent.id, action: 'No approved knowledge found; escalated', tool: 'faq.read', approvalState: 'n/a', result: 'pending' });
    if (conv) { conv.status = 'Escalated'; conv.nextAction = 'Owner to answer: no approved knowledge matched'; }
    return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge, conversationId: conv?.id, output: { task: input.text, result: 'I could not find approved information for this question, so I will not guess.', status: 'needs_information', blockers: ['No approved knowledge'], nextAction: 'Owner adds an FAQ or answers directly' } };
  }

  // Sensitive wording => manager escalates; agent only prepares a summary.
  if (decision.escalate) {
    const ap = createApproval(agent, 'workflow.trigger', 'Sensitive request escalated', `Escalated by Central AI Manager: "${input.text.slice(0, 160)}"`, 'High');
    recordAudit({ ...base, agent: agent.id, action: 'Escalated sensitive request to owner', tool: 'workflow.trigger', approvalState: 'pending', result: 'pending' });
    if (conv) { conv.status = 'Escalated'; conv.priority = 'Urgent'; conv.nextAction = 'Owner decision required'; }
    return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge, approvalId: ap.id, conversationId: conv?.id, output: { task: input.text, result: 'This involves a sensitive topic, so it was sent to the owner. No commitment has been made.', status: 'escalated', blockers: ['Owner decision required'], nextAction: 'Owner reviews in Approval Center' } };
  }

  const gate = authorizeTool(agent, decision.tool, d.manager);
  if (!gate.allowed) {
    recordAudit({ ...base, agent: agent.id, action: `Tool denied: ${TOOL_LABEL[decision.tool]}`, tool: decision.tool, approvalState: 'n/a', result: 'blocked', error: gate.reason });
    return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge, conversationId: conv?.id, output: { task: input.text, result: gate.reason, status: 'blocked', blockers: [gate.reason], nextAction: 'Owner can adjust agent permissions' } };
  }

  const ai = getAIProvider();
  const context = chunks.map(c => `[${c.source}] ${c.text}`).join('\n');
  const draft = await ai.chat([{ role: 'system', content: `${agent.instructions}\nApproved context:\n${context || '(none)'}` }, { role: 'user', content: input.text }]);

  if (conv) conv.messages.push({ id: nextId('m'), conversationId: conv.id, from: 'agent', text: draft, at: new Date().toISOString(), delivery: 'draft' });

  if (gate.needsApproval) {
    const ap = createApproval(agent, decision.tool, TOOL_LABEL[decision.tool], `${agent.name} drafted: "${draft.slice(0, 180)}"`, TOOL_RISK[decision.tool], conv?.id);
    recordAudit({ ...base, agent: agent.id, action: `Requested approval: ${TOOL_LABEL[decision.tool]}`, tool: decision.tool, approvalState: 'pending', result: 'pending' });
    if (conv) conv.nextAction = 'Awaiting owner approval';
    return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge, approvalId: ap.id, conversationId: conv?.id, output: { task: input.text, result: `Draft prepared. Nothing has been sent or published until the owner approves.`, status: 'awaiting_approval', blockers: ['Owner approval'], nextAction: 'Owner approves in Approval Center' } };
  }

  recordAudit({ ...base, agent: agent.id, action: TOOL_LABEL[decision.tool], tool: decision.tool, approvalState: 'n/a', result: 'success' });
  if (conv) conv.nextAction = 'Monitor reply';
  return { routedTo: agent.id, agentName: agent.name, reason: decision.reason, knowledge, conversationId: conv?.id, output: { task: input.text, result: draft, status: 'completed', blockers: [], nextAction: 'None' } };
}

function upsertConversation(input: { text: string; channel?: ChannelId; customerName?: string }, agent: AgentKey): Conversation {
  const d = db(); const name = input.customerName?.trim() || 'New customer'; const channel = input.channel ?? 'website';
  let c = d.conversations.find(x => x.customerName === name && x.channel === channel && x.status !== 'Resolved');
  const msg = { id: nextId('m'), conversationId: '', from: 'customer' as const, text: input.text, at: new Date().toISOString() };
  if (!c) { c = { id: nextId('c'), customerId: nextId('cu'), customerName: name, channel, assignedAgent: agent, status: 'Open', priority: 'Medium', lastActivity: msg.at, nextAction: 'Agent reviewing', tags: [], notes: [], messages: [] }; d.conversations.unshift(c); }
  msg.conversationId = c.id; c.messages.push(msg); c.lastActivity = msg.at; c.assignedAgent = agent;
  return c;
}

function createApproval(agent: Agent, tool: ToolId, action: string, summary: string, risk: Approval['risk'], conversationId?: string): Approval {
  const ap: Approval = { id: nextId('a'), action, requestedBy: agent.name, agent: agent.id, business: db().business.name, summary: conversationId ? `${summary} [conv:${conversationId}]` : summary, date: new Date().toISOString(), risk, state: 'pending', tool };
  db().approvals.unshift(ap);
  db().notifications.unshift({ id: nextId('n'), text: `Approval needed: ${action}`, at: ap.date, read: false });
  return ap;
}

/** Runs only AFTER the owner approves. Honest delivery: failure is reported, never faked. */
export async function executeApproved(ap: Approval, user: string): Promise<{ ok: boolean; message: string }> {
  const m = /\[conv:([^\]]+)\]/.exec(ap.summary);
  const conv = m ? db().conversations.find(c => c.id === m[1]) : undefined;
  if (ap.tool === 'message.send_external' || ap.tool === 'quote.publish') {
    if (!conv) return finish(ap, user, true, 'Approved. No linked conversation to deliver to.');
    const provider = getChannelProvider(conv.channel);
    const status = await provider.getStatus();
    const draft = [...conv.messages].reverse().find(x => x.delivery === 'draft');
    if (status.status !== 'connected') {
      if (draft) draft.delivery = 'blocked';
      return finish(ap, user, false, `Approved, but ${conv.channel} is not connected, so the message was not delivered.`);
    }
    const res = await provider.sendMessage(conv.customerName, draft?.text ?? '');
    if (draft) draft.delivery = res.ok ? 'sent' : 'blocked';
    if (res.ok) conv.nextAction = 'Monitor reply';
    return finish(ap, user, res.ok, res.ok ? 'Approved and delivered via demo provider.' : `Approved, but delivery failed: ${res.error}`);
  }
  return finish(ap, user, true, 'Approved.');
}
function finish(ap: Approval, user: string, ok: boolean, message: string) {
  recordAudit({ user, agent: ap.agent, action: `Executed: ${ap.action}`, tool: ap.tool, channel: null, approvalState: 'approved', result: ok ? 'success' : 'error', error: ok ? undefined : message });
  return { ok, message };
}
