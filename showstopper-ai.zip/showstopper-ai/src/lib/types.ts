export type Role = 'owner' | 'admin' | 'member' | 'viewer';
export type ChannelId = 'whatsapp' | 'email' | 'instagram' | 'website';
export type AgentKey = 'manager' | 'sales' | 'marketing' | 'support' | 'webdev' | 'research' | 'followup';
export type PermissionLevel = 'read_only' | 'draft_only' | 'act_with_approval' | 'act_autonomously';
export type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Won' | 'Lost' | 'Follow-up';
export const LEAD_STATUSES: LeadStatus[] = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost', 'Follow-up'];
export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type RiskLevel = 'Low' | 'Medium' | 'High';
export type ApprovalState = 'pending' | 'approved' | 'rejected' | 'changes_requested';
export type ToolId =
  | 'crm.read' | 'crm.write' | 'conversation.reply' | 'message.send_external' | 'task.create'
  | 'followup.schedule' | 'content.draft' | 'content.publish' | 'faq.read' | 'ticket.create'
  | 'research.run' | 'project.plan' | 'website.deploy' | 'quote.publish' | 'workflow.trigger';

export interface Business {
  id: string; name: string; type: string; description: string; location: string; services: string;
  targetCustomers: string; hours: string; contactEmail: string; language: string; websiteUrl: string;
  onboardingStep: number; onboardingComplete: boolean;
}
export interface Agent {
  id: AgentKey; name: string; role: string; description: string; instructions: string; enabled: boolean;
  allowedTools: ToolId[]; permissionLevel: PermissionLevel; requiresApproval: boolean;
  status: 'idle' | 'working' | 'paused' | 'needs_attention'; lastActivity: string;
}
export interface ManagerConfig {
  name: string; instructions: string; routingStrategy: 'rules' | 'ai_assisted' | 'hybrid';
  approvalMode: 'strict' | 'balanced' | 'relaxed'; escalationRules: string; allowedAgents: AgentKey[]; allowedTools: ToolId[];
}
export interface KnowledgeItem {
  id: string; category: 'Business' | 'Services' | 'Pricing' | 'FAQs' | 'Policies' | 'Brand Voice' | 'Internal Instructions' | 'Documents';
  title: string; content: string; approved: boolean; source: string; updatedAt: string;
}
export interface Customer { id: string; name: string; email?: string; phone?: string; optedOut: boolean }
export interface Message { id: string; conversationId: string; from: 'customer' | 'agent' | 'owner'; text: string; at: string; delivery?: 'draft' | 'sent' | 'blocked' }
export interface Conversation {
  id: string; customerId: string; customerName: string; channel: ChannelId; assignedAgent: AgentKey;
  status: 'Open' | 'Waiting' | 'Resolved' | 'Escalated'; priority: Priority; lastActivity: string; nextAction: string;
  tags: string[]; notes: string[]; messages: Message[];
}
export interface Lead {
  id: string; name: string; email: string; phone: string; company: string; source: string; channel: ChannelId;
  requirement: string; budget: string; status: LeadStatus; priority: Priority; assignedAgent: AgentKey;
  notes: string; nextFollowUp: string | null; createdAt: string; updatedAt: string;
}
export interface Approval {
  id: string; action: string; requestedBy: string; agent: AgentKey; business: string; summary: string;
  date: string; risk: RiskLevel; state: ApprovalState; decisionNote?: string; tool: ToolId;
}
export interface Task { id: string; title: string; agent: AgentKey; status: 'Open' | 'In progress' | 'Done'; due: string | null }
export interface AuditEvent {
  id: string; at: string; business: string; user: string; agent: AgentKey | null; action: string;
  tool: ToolId | null; channel: ChannelId | null; approvalState: ApprovalState | 'n/a'; result: 'success' | 'blocked' | 'error' | 'pending'; error?: string; detail?: string;
}
export interface Connection {
  channel: ChannelId; status: 'disconnected' | 'pending' | 'connected' | 'error'; mode: 'demo' | 'live';
  identifier: string; verifiedAt: string | null; permissions: string[]; lastError?: string;
}
export interface Automation { id: string; name: string; trigger: string; action: string; agent: AgentKey; enabled: boolean }
export interface Notification { id: string; text: string; at: string; read: boolean }
