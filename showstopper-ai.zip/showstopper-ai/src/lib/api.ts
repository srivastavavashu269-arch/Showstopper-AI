import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { ZodError, type ZodTypeAny, type z } from 'zod';
import { roleCan, type AppPermission } from './permissions';
import type { Role } from './types';

export interface Session { user: string; role: Role }
/** Level 1 demo session. Level 2 replaces this with real auth (e.g. Supabase) and tenant lookup. */
export function getSession(): Session {
  const role = cookies().get('ss_role')?.value as Role | undefined;
  const valid: Role[] = ['owner', 'admin', 'member', 'viewer'];
  const r = role && valid.includes(role) ? role : 'owner';
  return { user: `${r}@brightline.example`, role: r };
}
export class HttpError extends Error { constructor(public status: number, message: string, public fields?: Record<string, string>) { super(message); } }

const hits = new Map<string, { n: number; t: number }>();
/** Simple in-process limiter. Production: move to Redis/edge store keyed by tenant+user+IP. */
export function rateLimit(key: string, max = 60, windowMs = 60000) {
  const now = Date.now(); const h = hits.get(key);
  if (!h || now - h.t > windowMs) { hits.set(key, { n: 1, t: now }); return; }
  h.n += 1; if (h.n > max) throw new HttpError(429, 'Too many requests. Try again in a minute.');
}
export function guard(permission: AppPermission, key = 'api'): Session {
  const s = getSession(); rateLimit(`${s.user}:${key}`);
  if (!roleCan(s.role, permission)) throw new HttpError(403, `Your role (${s.role}) cannot do this. Ask the owner.`);
  return s;
}
export async function parse<S extends ZodTypeAny>(req: Request, schema: S): Promise<z.infer<S>> {
  let body: unknown; try { body = await req.json(); } catch { throw new HttpError(400, 'Request body must be valid JSON'); }
  const r = schema.safeParse(body);
  if (!r.success) throw new HttpError(422, 'Please fix the highlighted fields', fieldErrors(r.error));
  return r.data;
}
function fieldErrors(e: ZodError) { const o: Record<string, string> = {}; for (const i of e.issues) o[i.path.join('.') || 'form'] ??= i.message; return o; }
export function ok<T>(data: T, status = 200) { return NextResponse.json({ ok: true, data }, { status }); }
export async function handle(fn: () => Promise<Response> | Response): Promise<Response> {
  try { return await fn(); } catch (e) {
    if (e instanceof HttpError) return NextResponse.json({ ok: false, error: e.message, fields: e.fields }, { status: e.status });
    console.error('API error', e instanceof Error ? e.message : 'unknown');
    return NextResponse.json({ ok: false, error: 'Something went wrong on our side. Try again.' }, { status: 500 });
  }
}
