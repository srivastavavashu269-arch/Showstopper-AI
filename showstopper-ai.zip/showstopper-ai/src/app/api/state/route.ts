import { db } from '@/lib/store';
import { guard, handle, ok } from '@/lib/api';
export const dynamic = 'force-dynamic';
export async function GET() {
  return handle(() => { const s = guard('view', 'state'); const d = db(); return ok({ session: s, ...d, seq: undefined }); });
}
