import { z } from 'zod';
import { db } from '@/lib/store';
import { guard, handle, ok, parse } from '@/lib/api';
import { businessProfileSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
const schema = businessProfileSchema.partial().extend({ onboardingStep: z.number().int().min(0).max(8).optional(), onboardingComplete: z.boolean().optional(), validateAll: z.boolean().optional() });
export async function PATCH(req: Request) {
  return handle(async () => { const s = guard('edit_settings', 'business'); const { validateAll, ...b } = await parse(req, schema);
    if (validateAll) { const { onboardingStep, onboardingComplete, ...rest } = b; await Promise.resolve(businessProfileSchema.parse({ ...db().business, ...rest })); }
    Object.assign(db().business, b);
    recordAudit({ user: s.user, agent: null, action: 'Business settings updated', tool: null, channel: null, approvalState: 'n/a', result: 'success' }); return ok(db().business); });
}
