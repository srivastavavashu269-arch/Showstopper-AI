import { z } from 'zod';
import { HttpError, guard, handle, ok, parse } from '@/lib/api';
import { getChannelProvider, CHANNELS } from '@/lib/providers/channels/registry';
import { recordAudit } from '@/lib/audit';
import type { ChannelId } from '@/lib/types';
const schema = z.object({ action: z.enum(['connect', 'verify', 'disconnect']), identifier: z.string().trim().max(200).optional() });
export async function POST(req: Request, { params }: { params: { channel: string } }) {
  return handle(async () => { const s = guard('manage_connections', 'connections'); const b = await parse(req, schema);
    if (!CHANNELS.includes(params.channel as ChannelId)) throw new HttpError(404, 'Unknown channel');
    const p = getChannelProvider(params.channel as ChannelId);
    const conn = b.action === 'connect' ? await p.connect(b.identifier ?? '') : b.action === 'verify' ? await p.verifyConnection() : await p.disconnect();
    recordAudit({ user: s.user, agent: null, action: `Channel ${b.action}`, tool: null, channel: p.channel, approvalState: 'n/a', result: conn.status === 'error' ? 'error' : 'success', error: conn.lastError });
    return ok(conn); });
}
