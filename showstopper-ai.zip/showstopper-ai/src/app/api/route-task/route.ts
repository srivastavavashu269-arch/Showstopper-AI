import { guard, handle, ok, parse } from '@/lib/api';
import { routeTaskSchema } from '@/lib/validation';
import { routeTask } from '@/lib/manager';
export async function POST(req: Request) {
  return handle(async () => { const s = guard('run_tasks', 'route'); const b = await parse(req, routeTaskSchema);
    return ok(await routeTask({ ...b, user: s.user })); });
}
