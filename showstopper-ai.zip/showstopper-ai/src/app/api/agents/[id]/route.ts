import { db } from '@/lib/store';
import { HttpError, guard, handle, ok, parse } from '@/lib/api';
import { agentPatchSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
import { TOOL_LABEL } from '@/lib/permissions';
import type { Agent, ToolId } from '@/lib/types';
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('edit_agents', 'agents'); const b = await parse(req, agentPatchSchema);
    const a = db().agents.find(x => x.id === params.id); if (!a) throw new HttpError(404, 'Agent not found');
    if (b.allowedTools) { const bad = b.allowedTools.filter(t => !(t in TOOL_LABEL)); if (bad.length) throw new HttpError(422, 'Unknown tool selected', { allowedTools: `Unknown: ${bad.join(', ')}` }); }
    Object.assign(a, b as Partial<Agent> & { allowedTools?: ToolId[] });
    recordAudit({ user: s.user, agent: a.id, action: 'Agent configuration changed', tool: null, channel: null, approvalState: 'n/a', result: 'success' });
    return ok(a); });
}
