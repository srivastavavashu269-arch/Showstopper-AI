import { db } from '@/lib/store';
import { HttpError, guard, handle, ok, parse } from '@/lib/api';
import { approvalDecisionSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
import { executeApproved } from '@/lib/manager';
export async function POST(req: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('decide_approvals', 'approvals'); const b = await parse(req, approvalDecisionSchema);
    const ap = db().approvals.find(a => a.id === params.id); if (!ap) throw new HttpError(404, 'Approval not found');
    if (ap.state !== 'pending') throw new HttpError(409, `This request was already ${ap.state.replace('_', ' ')}`);
    ap.decisionNote = b.note;
    if (b.decision === 'approve') { ap.state = 'approved'; const r = await executeApproved(ap, s.user); return ok({ approval: ap, execution: r }); }
    ap.state = b.decision === 'reject' ? 'rejected' : 'changes_requested';
    recordAudit({ user: s.user, agent: ap.agent, action: `${ap.action} ${ap.state.replace('_', ' ')}`, tool: ap.tool, channel: null, approvalState: ap.state, result: 'success' });
    return ok({ approval: ap }); });
}
