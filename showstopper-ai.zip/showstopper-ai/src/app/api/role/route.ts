import { z } from 'zod';
import { NextResponse } from 'next/server';
import { handle, parse } from '@/lib/api';
export async function POST(req: Request) {
  return handle(async () => { const b = await parse(req, z.object({ role: z.enum(['owner', 'admin', 'member', 'viewer']) }));
    const res = NextResponse.json({ ok: true, data: b }); res.cookies.set('ss_role', b.role, { httpOnly: true, sameSite: 'lax', path: '/' }); return res; });
}
