import { db } from '@/lib/store';
import { HttpError, guard, handle, ok } from '@/lib/api';
export async function PATCH(_: Request, { params }: { params: { id: string } }) {
  return handle(() => { guard('edit_settings', 'automations'); const a = db().automations.find(x => x.id === params.id); if (!a) throw new HttpError(404, 'Automation not found'); a.enabled = !a.enabled; return ok(a); });
}
