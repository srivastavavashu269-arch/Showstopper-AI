import { guard, handle, ok } from '@/lib/api';
import { resetDb } from '@/lib/store';
export async function POST() { return handle(() => { guard('edit_settings', 'reset'); resetDb(); return ok({ reset: true }); }); }
