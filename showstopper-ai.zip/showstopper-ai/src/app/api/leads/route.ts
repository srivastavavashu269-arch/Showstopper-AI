import { db, nextId } from '@/lib/store';
import { guard, handle, ok, parse } from '@/lib/api';
import { leadSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
import type { Lead } from '@/lib/types';
export async function POST(req: Request) {
  return handle(async () => { const s = guard('edit_leads', 'leads'); const b = await parse(req, leadSchema); const now = new Date().toISOString();
    const lead = { ...b, id: nextId('l'), createdAt: now, updatedAt: now } as Lead; db().leads.unshift(lead);
    recordAudit({ user: s.user, agent: null, action: `Lead created: ${lead.name}`, tool: 'crm.write', channel: lead.channel, approvalState: 'n/a', result: 'success' });
    return ok(lead, 201); });
}
