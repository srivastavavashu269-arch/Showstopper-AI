import { db } from '@/lib/store';
import { HttpError, guard, handle, ok, parse } from '@/lib/api';
import { leadPatchSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
import type { Lead } from '@/lib/types';
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('edit_leads', 'leads'); const b = await parse(req, leadPatchSchema);
    const lead = db().leads.find(l => l.id === params.id); if (!lead) throw new HttpError(404, 'Lead not found');
    Object.assign(lead, b as Partial<Lead>, { updatedAt: new Date().toISOString() });
    recordAudit({ user: s.user, agent: null, action: `Lead updated: ${lead.name}`, tool: 'crm.write', channel: lead.channel, approvalState: 'n/a', result: 'success' });
    return ok(lead); });
}
