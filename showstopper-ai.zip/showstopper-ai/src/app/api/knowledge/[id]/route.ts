import { db } from '@/lib/store';
import { HttpError, guard, handle, ok } from '@/lib/api';
import { recordAudit } from '@/lib/audit';
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('edit_knowledge', 'knowledge'); const i = db().knowledge.find(k => k.id === params.id); if (!i) throw new HttpError(404, 'Item not found');
    i.approved = !i.approved; i.updatedAt = new Date().toISOString();
    recordAudit({ user: s.user, agent: null, action: `Knowledge ${i.approved ? 'approved' : 'unapproved'}: ${i.title}`, tool: null, channel: null, approvalState: 'n/a', result: 'success' }); return ok(i); });
}
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('edit_knowledge', 'knowledge'); const d = db(); const n = d.knowledge.length; d.knowledge = d.knowledge.filter(k => k.id !== params.id);
    if (d.knowledge.length === n) throw new HttpError(404, 'Item not found');
    recordAudit({ user: s.user, agent: null, action: 'Knowledge removed', tool: null, channel: null, approvalState: 'n/a', result: 'success' }); return ok({ id: params.id }); });
}
