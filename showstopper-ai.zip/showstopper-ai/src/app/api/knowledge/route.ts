import { db, nextId } from '@/lib/store';
import { guard, handle, ok, parse } from '@/lib/api';
import { knowledgeSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
export async function POST(req: Request) {
  return handle(async () => { const s = guard('edit_knowledge', 'knowledge'); const b = await parse(req, knowledgeSchema);
    const item = { ...b, id: nextId('k'), approved: true, source: s.user, updatedAt: new Date().toISOString() }; db().knowledge.unshift(item);
    recordAudit({ user: s.user, agent: null, action: `Knowledge added: ${item.title}`, tool: null, channel: null, approvalState: 'n/a', result: 'success' });
    return ok(item, 201); });
}
