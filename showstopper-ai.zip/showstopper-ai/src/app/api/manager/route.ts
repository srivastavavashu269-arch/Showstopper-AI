import { db } from '@/lib/store';
import { guard, handle, ok, parse } from '@/lib/api';
import { managerPatchSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
import type { ManagerConfig } from '@/lib/types';
export async function PATCH(req: Request) {
  return handle(async () => { const s = guard('edit_manager', 'manager'); const b = await parse(req, managerPatchSchema);
    Object.assign(db().manager, b as Partial<ManagerConfig>);
    recordAudit({ user: s.user, agent: 'manager', action: 'Central AI Manager configuration changed', tool: null, channel: null, approvalState: 'n/a', result: 'success' });
    return ok(db().manager); });
}
