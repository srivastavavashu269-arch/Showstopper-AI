import { db } from '@/lib/store';
import { HttpError, guard, handle, ok, parse } from '@/lib/api';
import { conversationPatchSchema } from '@/lib/validation';
import { recordAudit } from '@/lib/audit';
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  return handle(async () => { const s = guard('edit_leads', 'inbox'); const b = await parse(req, conversationPatchSchema);
    const c = db().conversations.find(x => x.id === params.id); if (!c) throw new HttpError(404, 'Conversation not found');
    if (b.status) c.status = b.status; if (b.priority) c.priority = b.priority; if (b.assignedAgent) c.assignedAgent = b.assignedAgent; if (b.nextAction) c.nextAction = b.nextAction;
    if (b.addNote) c.notes.push(b.addNote); if (b.addTag && !c.tags.includes(b.addTag)) c.tags.push(b.addTag);
    c.lastActivity = new Date().toISOString();
    recordAudit({ user: s.user, agent: c.assignedAgent, action: 'Conversation updated', tool: null, channel: c.channel, approvalState: 'n/a', result: 'success' });
    return ok(c); });
}
