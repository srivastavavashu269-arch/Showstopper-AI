import './globals.css';
import type { Metadata, Viewport } from 'next';
import { AppProvider } from '@/components/AppProvider';
export const metadata: Metadata = { title: 'Showstopper-AI', description: 'Your AI workforce, run from one control room.' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body><AppProvider>{children}</AppProvider></body></html>);
}
