'use client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { Badge, Button, Card, Field, inputCls, useToast, cx } from '@/components/ui';
import { ConnectionCard } from '@/components/ConnectionCard';
import { TOOL_LABEL } from '@/lib/permissions';
import type { Business, KnowledgeItem, PermissionLevel } from '@/lib/types';
import type { RouteOutcome } from '@/lib/manager';

const STEPS = ['Welcome', 'Business Profile', 'Business Knowledge', 'AI Team', 'Central AI Manager', 'Connect Channels', 'Permissions', 'Review & Test'];
const CATS: KnowledgeItem['category'][] = ['Business', 'Services', 'Pricing', 'FAQs', 'Policies', 'Brand Voice', 'Internal Instructions', 'Documents'];
const LEVELS: [PermissionLevel, string][] = [['read_only', 'Read only'], ['draft_only', 'Draft only'], ['act_with_approval', 'Act with approval'], ['act_autonomously', 'Act on its own']];

export default function Onboarding() {
  const { state, call } = useApp(); const router = useRouter(); const t = useToast();
  const [step, setStep] = useState(0); const [started, setStarted] = useState(false);
  useEffect(() => { if (state && !started) setStep(state.business.onboardingStep); }, [state, started]);
  if (!state) return <div className="grid min-h-screen place-items-center text-sm text-ink-soft">Loading…</div>;
  async function go(n: number) { setStarted(true); setStep(n); await call('/api/business', 'PATCH', { onboardingStep: n }); window.scrollTo({ top: 0 }); }

  return (
    <div className="min-h-screen bg-ink text-ink">
      <div className="mx-auto max-w-3xl px-4 py-8 sm:py-12">
        <p className="mb-6 text-lg font-semibold text-white">Showstopper-AI</p>
        {step > 0 && <ol className="mb-5 flex gap-1.5" aria-label="Setup progress">{STEPS.slice(1).map((s, i) => (<li key={s} className="flex-1"><div className={cx('h-1.5 rounded-full', i + 1 <= step ? 'bg-spot' : 'bg-white/20')} /><span className="sr-only">{s}</span></li>))}</ol>}
        <div className="rounded-2xl bg-paper-card p-5 sm:p-8">
          {step > 0 && <p className="mb-1 text-sm text-ink-soft">Step {step} of {STEPS.length - 1}: {STEPS[step]}</p>}
          {step === 0 && <Welcome onStart={() => go(1)} onContinue={() => go(state.business.onboardingStep || 1)} canContinue={state.business.onboardingStep > 0} onDemo={async () => { await call('/api/business', 'PATCH', { onboardingComplete: true, onboardingStep: 8 }); router.push('/dashboard'); }} />}
          {step === 1 && <Profile b={state.business} next={() => go(2)} back={() => go(0)} />}
          {step === 2 && <Knowledge next={() => go(3)} back={() => go(1)} />}
          {step === 3 && <Team next={() => go(4)} back={() => go(2)} />}
          {step === 4 && <ManagerStep next={() => go(5)} back={() => go(3)} />}
          {step === 5 && <Channels next={() => go(6)} back={() => go(4)} />}
          {step === 6 && <Perms next={() => go(7)} back={() => go(5)} />}
          {step === 7 && <Review back={() => go(6)} finish={async () => { const r = await call('/api/business', 'PATCH', { onboardingComplete: true, onboardingStep: 8, validateAll: true }); if (!r.ok) { t.show(r.error ?? 'Complete your business profile first', 'bad'); return; } router.push('/dashboard'); }} />}
        </div>
      </div>
      {t.node}
    </div>
  );
}

function Nav({ back, next, nextLabel = 'Continue', disabled }: { back?: () => void; next: () => void; nextLabel?: string; disabled?: boolean }) {
  return <div className="mt-6 flex justify-between gap-3">{back ? <Button variant="secondary" onClick={back}>Back</Button> : <span />}<Button onClick={next} disabled={disabled}>{nextLabel}</Button></div>;
}
function Welcome({ onStart, onContinue, canContinue, onDemo }: { onStart: () => void; onContinue: () => void; canContinue: boolean; onDemo: () => void }) {
  return (<div className="py-6 text-center sm:py-12">
    <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">Build Your AI Workforce</h1>
    <p className="mx-auto mt-3 max-w-md text-ink-soft">Set up your business, your AI team, and your communication channels.</p>
    <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"><Button className="min-w-44" onClick={onStart}>Start Setup</Button><Button variant="secondary" className="min-w-44" disabled={!canContinue} onClick={onContinue}>Continue Existing Setup</Button></div>
    <button className="mt-6 text-sm text-stage underline" onClick={onDemo}>Skip setup and explore the demo workspace</button>
  </div>);
}

function Profile({ b, next, back }: { b: Business; next: () => void; back: () => void }) {
  const { call } = useApp(); const [f, setF] = useState({ name: b.name, type: b.type, description: b.description, location: b.location, services: b.services, targetCustomers: b.targetCustomers, hours: b.hours, contactEmail: b.contactEmail, language: b.language, websiteUrl: b.websiteUrl });
  const [errs, setErrs] = useState<Record<string, string>>({}); const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  async function save() { setBusy(true); const r = await call('/api/business', 'PATCH', f); setBusy(false); if (r.ok) next(); else setErrs(r.fields ?? { form: r.error ?? 'Could not save' }); }
  return (<div><h2 className="text-2xl font-semibold">Tell us about your business</h2>
    <div className="mt-5 grid gap-4 sm:grid-cols-2">
      <Field label="Business name" error={errs.name}><input className={inputCls} value={f.name} onChange={set('name')} /></Field>
      <Field label="Business type" error={errs.type}><input className={inputCls} value={f.type} onChange={set('type')} /></Field>
      <div className="sm:col-span-2"><Field label="Description" error={errs.description}><textarea rows={3} className={inputCls} value={f.description} onChange={set('description')} /></Field></div>
      <Field label="Location" error={errs.location}><input className={inputCls} value={f.location} onChange={set('location')} /></Field>
      <Field label="Business hours" error={errs.hours}><input className={inputCls} value={f.hours} onChange={set('hours')} /></Field>
      <Field label="Services" error={errs.services}><textarea rows={2} className={inputCls} value={f.services} onChange={set('services')} /></Field>
      <Field label="Target customers" error={errs.targetCustomers}><textarea rows={2} className={inputCls} value={f.targetCustomers} onChange={set('targetCustomers')} /></Field>
      <Field label="Contact email" error={errs.contactEmail}><input type="email" className={inputCls} value={f.contactEmail} onChange={set('contactEmail')} /></Field>
      <Field label="Preferred language" error={errs.language}><select className={inputCls} value={f.language} onChange={set('language')}><option>English</option><option>Hindi</option><option>Urdu</option><option>Spanish</option><option>Arabic</option></select></Field>
      <div className="sm:col-span-2"><Field label="Website URL (optional)" error={errs.websiteUrl} hint="Used for public analysis only. It does not give the AI access to manage your site."><input className={inputCls} value={f.websiteUrl} onChange={set('websiteUrl')} /></Field></div>
    </div>
    {errs.form && <p role="alert" className="mt-3 text-sm text-bad">{errs.form}</p>}
    <Nav back={back} next={save} disabled={busy} /></div>);
}

function Knowledge({ next, back }: { next: () => void; back: () => void }) {
  const { state, call } = useApp(); const [cat, setCat] = useState<KnowledgeItem['category']>('FAQs'); const [title, setTitle] = useState(''); const [content, setContent] = useState(''); const [errs, setErrs] = useState<Record<string, string>>({});
  async function add() { const r = await call('/api/knowledge', 'POST', { category: cat, title, content }); if (r.ok) { setTitle(''); setContent(''); setErrs({}); } else setErrs(r.fields ?? { form: r.error ?? 'Could not add' }); }
  return (<div><h2 className="text-2xl font-semibold">Teach your AI team about your business</h2><p className="mt-1 text-sm text-ink-soft">All agents share this approved knowledge. Add services, pricing, FAQs, policies, brand voice and rules.</p>
    <div className="mt-4 grid gap-3 sm:grid-cols-[180px_1fr]"><Field label="Category"><select className={inputCls} value={cat} onChange={e => setCat(e.target.value as KnowledgeItem['category'])}>{CATS.map(c => <option key={c}>{c}</option>)}</select></Field><Field label="Title" error={errs.title}><input className={inputCls} value={title} onChange={e => setTitle(e.target.value)} /></Field></div>
    <div className="mt-3"><Field label="Content" error={errs.content}><textarea rows={3} className={inputCls} value={content} onChange={e => setContent(e.target.value)} /></Field></div>
    <Button variant="secondary" className="mt-3" onClick={add}>Add to knowledge base</Button>
    <p className="mt-5 text-sm font-medium">{state?.knowledge.length ?? 0} items in your knowledge base</p>
    <ul className="mt-2 max-h-48 divide-y divide-paper-line overflow-y-auto rounded-lg border border-paper-line">{state?.knowledge.map(k => <li key={k.id} className="flex justify-between gap-2 px-3 py-2 text-sm"><span>{k.title}</span><Badge tone="stage">{k.category}</Badge></li>)}</ul>
    <Nav back={back} next={next} /></div>);
}

function Team({ next, back }: { next: () => void; back: () => void }) {
  const { state, call } = useApp();
  return (<div><h2 className="text-2xl font-semibold">Your AI team</h2><p className="mt-1 text-sm text-ink-soft">Six specialists are ready. Turn off any you do not need yet.</p>
    <ul className="mt-4 space-y-3">{state?.agents.map(a => (<li key={a.id} className="flex items-start justify-between gap-3 rounded-lg border border-paper-line p-3"><div><p className="font-medium">{a.name}</p><p className="text-sm text-ink-soft">{a.role}</p></div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#4B3FE0]" checked={a.enabled} onChange={e => call(`/api/agents/${a.id}`, 'PATCH', { enabled: e.target.checked })} />Enabled</label></li>))}</ul>
    <Nav back={back} next={next} /></div>);
}

function ManagerStep({ next, back }: { next: () => void; back: () => void }) {
  const { state, call } = useApp(); const m = state!.manager; const [name, setName] = useState(m.name); const [ins, setIns] = useState(m.instructions); const [esc, setEsc] = useState(m.escalationRules);
  const [strategy, setStrategy] = useState(m.routingStrategy); const [mode, setMode] = useState(m.approvalMode); const [errs, setErrs] = useState<Record<string, string>>({});
  async function save() { const r = await call('/api/manager', 'PATCH', { name, instructions: ins, escalationRules: esc, routingStrategy: strategy, approvalMode: mode }); if (r.ok) next(); else setErrs(r.fields ?? { form: r.error ?? 'Could not save' }); }
  return (<div><h2 className="text-2xl font-semibold">Central AI Manager</h2><p className="mt-1 text-sm text-ink-soft">The manager routes work to your specialists and escalates sensitive actions to you.</p>
    <div className="mt-4 grid gap-4 sm:grid-cols-3"><Field label="Manager name" error={errs.name}><input className={inputCls} value={name} onChange={e => setName(e.target.value)} /></Field>
      <Field label="Routing strategy"><select className={inputCls} value={strategy} onChange={e => setStrategy(e.target.value as typeof strategy)}><option value="rules">Rules</option><option value="ai_assisted">AI-assisted</option><option value="hybrid">Hybrid</option></select></Field>
      <Field label="Approval mode"><select className={inputCls} value={mode} onChange={e => setMode(e.target.value as typeof mode)}><option value="strict">Strict</option><option value="balanced">Balanced</option><option value="relaxed">Relaxed</option></select></Field></div>
    <div className="mt-4"><Field label="Manager instructions" error={errs.instructions}><textarea rows={8} className={inputCls} value={ins} onChange={e => setIns(e.target.value)} /></Field></div>
    <div className="mt-4"><Field label="Escalation rules"><textarea rows={2} className={inputCls} value={esc} onChange={e => setEsc(e.target.value)} /></Field></div>
    <Nav back={back} next={save} /></div>);
}

function Channels({ next, back }: { next: () => void; back: () => void }) {
  const { state } = useApp();
  return (<div><h2 className="text-2xl font-semibold">Connect your channels</h2><p className="mt-1 text-sm text-ink-soft">Entering an account does not connect it. A channel shows as connected only after a successful test. This version runs in demo mode.</p>
    <div className="mt-4 grid gap-3">{state?.connections.map(c => <ConnectionCard key={c.channel} conn={c} compact />)}</div>
    <Nav back={back} next={next} nextLabel="Continue (you can connect later)" /></div>);
}

function Perms({ next, back }: { next: () => void; back: () => void }) {
  const { state, call } = useApp();
  return (<div><h2 className="text-2xl font-semibold">Permissions</h2><p className="mt-1 text-sm text-ink-soft">Choose how much each agent may do. Sending messages, publishing, quotations and deployments always need your approval.</p>
    <ul className="mt-4 space-y-3">{state?.agents.filter(a => a.enabled).map(a => (<li key={a.id} className="rounded-lg border border-paper-line p-3"><p className="font-medium">{a.name}</p>
      <div className="mt-2 grid gap-3 sm:grid-cols-2"><Field label="Permission level"><select className={inputCls} value={a.permissionLevel} onChange={e => call(`/api/agents/${a.id}`, 'PATCH', { permissionLevel: e.target.value })}>{LEVELS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
        <label className="flex items-center gap-2 pt-6 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#4B3FE0]" checked={a.requiresApproval} onChange={e => call(`/api/agents/${a.id}`, 'PATCH', { requiresApproval: e.target.checked })} />Require my approval for impactful actions</label></div>
      <p className="mt-2 text-xs text-ink-mute">Tools: {a.allowedTools.map(t => TOOL_LABEL[t]).join(', ')}</p></li>))}</ul>
    <Nav back={back} next={next} /></div>);
}

function Review({ back, finish }: { back: () => void; finish: () => void }) {
  const { state, call } = useApp(); const [out, setOut] = useState<RouteOutcome | null>(null);
  const s = state!; const connected = s.connections.filter(c => c.status === 'connected').length;
  async function test() { const r = await call<RouteOutcome>('/api/route-task', 'POST', { text: 'Do you offer monthly maintenance for websites?', source: 'owner' }); if (r.ok && r.data) setOut(r.data); }
  const rows: [string, string][] = [['Business', `${s.business.name}, ${s.business.location}`], ['Knowledge items', String(s.knowledge.length)], ['Active agents', `${s.agents.filter(a => a.enabled).length} of ${s.agents.length}`], ['Manager', `${s.manager.name} · ${s.manager.approvalMode} approvals`], ['Channels connected (demo)', `${connected} of ${s.connections.length}`]];
  return (<div><h2 className="text-2xl font-semibold">Review and test</h2>
    <dl className="mt-4 divide-y divide-paper-line rounded-lg border border-paper-line">{rows.map(([k, v]) => <div key={k} className="flex justify-between gap-3 px-3 py-2 text-sm"><dt className="text-ink-soft">{k}</dt><dd className="text-right font-medium">{v}</dd></div>)}</dl>
    <Card className="mt-4"><p className="font-medium">Try a sample question</p><p className="text-sm text-ink-soft">&ldquo;Do you offer monthly maintenance for websites?&rdquo;</p><Button variant="secondary" className="mt-2" onClick={test}>Run routing test</Button>
      {out && <div className="mt-3 rounded-lg bg-stage-tint p-3 text-sm" role="status"><p>Routed to <strong>{out.agentName}</strong>. {out.output.result}</p>{out.knowledge[0] && <p className="mt-1 text-xs text-ink-soft">Answered from: {out.knowledge[0].source}</p>}</div>}</Card>
    <Nav back={back} next={finish} nextLabel="Activate and open dashboard" /></div>);
}
