'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { Button, cx } from '@/components/ui';

const NAV = [
  ['Dashboard', '/dashboard'], ['Shared Inbox', '/inbox'], ['AI Agents', '/agents'], ['Leads / CRM', '/leads'], ['Knowledge Base', '/knowledge'],
  ['Automations', '/automations'], ['Approval Center', '/approvals'], ['Analytics', '/analytics'], ['Connections', '/connections'], ['Settings', '/settings'],
] as const;

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { state, loading, error, refresh, call } = useApp();
  const path = usePathname(); const router = useRouter(); const [open, setOpen] = useState(false);
  useEffect(() => { if (state && !state.business.onboardingComplete) router.replace('/onboarding'); }, [state, router]);
  useEffect(() => setOpen(false), [path]);
  if (loading) return <div className="grid min-h-screen place-items-center text-sm text-ink-soft" role="status">Loading your control room…</div>;
  if (error || !state) return (<div className="grid min-h-screen place-items-center p-6"><div className="max-w-sm text-center"><p className="font-medium">We couldn&apos;t load your workspace</p><p className="mt-1 text-sm text-ink-soft">{error}</p><Button className="mt-4" onClick={refresh}>Try again</Button></div></div>);
  if (!state.business.onboardingComplete) return null;
  const pending = state.approvals.filter(a => a.state === 'pending').length;
  const nav = (
    <nav aria-label="Main" className="flex flex-col gap-0.5 p-3">
      {NAV.map(([label, href]) => { const active = path.startsWith(href); return (
        <Link key={href} href={href} aria-current={active ? 'page' : undefined} className={cx('flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors', active ? 'bg-white/12 font-medium text-white' : 'text-white/70 hover:bg-white/8 hover:text-white')}>
          <span>{label}</span>{label === 'Approval Center' && pending > 0 && <span className="rounded-full bg-spot px-2 text-xs font-semibold text-ink">{pending}</span>}
        </Link>); })}
    </nav>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
      <aside className="hidden bg-ink lg:block"><div className="sticky top-0 flex h-screen flex-col">
        <div className="px-5 pb-2 pt-5"><p className="text-lg font-semibold text-white">Showstopper-AI</p><p className="truncate text-xs text-white/60">{state.business.name}</p></div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        <div className="border-t border-white/10 p-4 text-xs text-white/60">Demo mode. No live accounts are connected.</div>
      </div></aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-paper-line bg-paper-card/95 px-4 py-2.5 backdrop-blur">
          <div className="flex items-center gap-2"><button className="rounded-lg border border-paper-line px-3 py-2 text-sm lg:hidden" aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}>Menu</button><span className="font-semibold lg:hidden">Showstopper-AI</span></div>
          <label className="flex items-center gap-2 text-xs text-ink-soft">Viewing as
            <select className="rounded-lg border border-paper-line bg-white px-2 py-1.5 text-sm text-ink" value={state.session.role} onChange={async e => { await call('/api/role', 'POST', { role: e.target.value }); }}>
              <option value="owner">Owner</option><option value="admin">Admin</option><option value="member">Member</option><option value="viewer">Viewer</option>
            </select></label>
        </header>
        {open && <div id="mobile-nav" className="bg-ink lg:hidden">{nav}</div>}
        <main className="mx-auto max-w-[1280px] p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
