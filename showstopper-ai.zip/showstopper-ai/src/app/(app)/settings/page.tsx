'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Badge, Button, Card, Field, PageHeader, ago, inputCls, useToast, cx } from '@/components/ui';

const TABS = ['Business', 'Users', 'Agents', 'Permissions', 'Channels', 'Notifications', 'AI', 'Security', 'Billing', 'Audit Logs'] as const;
export default function Settings() {
  const { state, call } = useApp(); const t = useToast(); const [tab, setTab] = useState<(typeof TABS)[number]>('Business'); const [errs, setErrs] = useState<Record<string, string>>({});
  const [b, setB] = useState(state?.business); if (!state || !b) return null;
  async function saveBiz() { const { id, onboardingStep, onboardingComplete, ...rest } = b!; const r = await call('/api/business', 'PATCH', rest); if (r.ok) { setErrs({}); t.show('Business saved'); } else { setErrs(r.fields ?? {}); t.show(r.error ?? 'Could not save', 'bad'); } }
  return (<><PageHeader title="Settings" />
    <div className="mb-4 flex gap-1.5 overflow-x-auto pb-1" role="tablist">{TABS.map(x => <button key={x} role="tab" aria-selected={tab === x} onClick={() => setTab(x)} className={cx('whitespace-nowrap rounded-full px-3 py-1.5 text-sm', tab === x ? 'bg-ink text-white' : 'border border-paper-line bg-white')}>{x === 'Audit Logs' ? 'Audit logs' : x}</button>)}</div>
    <Card>
      {tab === 'Business' && <div className="grid gap-3 sm:grid-cols-2">{(['name', 'type', 'location', 'hours', 'contactEmail', 'websiteUrl'] as const).map(k => <Field key={k} label={k === 'contactEmail' ? 'Contact email' : k === 'websiteUrl' ? 'Website URL' : k[0].toUpperCase() + k.slice(1)} error={errs[k]}><input className={inputCls} value={b[k]} onChange={e => setB({ ...b, [k]: e.target.value })} /></Field>)}
        <div className="sm:col-span-2"><Field label="Description" error={errs.description}><textarea rows={3} className={inputCls} value={b.description} onChange={e => setB({ ...b, description: e.target.value })} /></Field></div><div><Button onClick={saveBiz}>Save business</Button></div></div>}
      {tab === 'Users' && <ul className="divide-y divide-paper-line text-sm"><li className="flex justify-between py-2"><span>owner@brightline.example</span><Badge tone="stage">Owner</Badge></li><li className="flex justify-between py-2"><span>admin@brightline.example</span><Badge>Admin</Badge></li><li className="flex justify-between py-2"><span>member@brightline.example</span><Badge>Member</Badge></li><li className="py-2 text-ink-soft">Use the &ldquo;Viewing as&rdquo; switcher at the top to test each role. Real invitations arrive with authentication in Level 2.</li></ul>}
      {tab === 'Agents' && <ul className="space-y-1 text-sm">{state.agents.map(a => <li key={a.id} className="flex justify-between"><span>{AGENT_NAMES[a.id]}</span><Badge tone={a.enabled ? 'ok' : 'neutral'}>{a.enabled ? 'Enabled' : 'Disabled'}</Badge></li>)}<li className="pt-2"><Link className="text-stage" href="/agents">Configure agents</Link></li></ul>}
      {tab === 'Permissions' && <div className="space-y-2 text-sm"><p>Roles are checked on the server for every request.</p><ul className="list-disc pl-5 text-ink-soft"><li>Owner: everything, including approvals and the Central AI Manager</li><li>Admin: agents, knowledge, connections, settings</li><li>Member: leads, inbox and running tasks</li><li>Viewer: read only</li></ul></div>}
      {tab === 'Channels' && <p className="text-sm">Channels are managed in <Link className="text-stage" href="/connections">Connections</Link>. All current connections are demo-mode.</p>}
      {tab === 'Notifications' && (state.notifications.length === 0 ? <p className="text-sm text-ink-soft">No notifications yet. Approval requests will appear here.</p> : <ul className="space-y-1 text-sm">{state.notifications.slice(0, 10).map(n => <li key={n.id}>{n.text} <span className="text-ink-mute">· {ago(n.at)}</span></li>)}</ul>)}
      {tab === 'AI' && <div className="space-y-2 text-sm"><p>AI provider: <strong>Mock (demo)</strong>. Set <code>AI_PROVIDER=nvidia-nim</code> and server-side keys in your environment to use NVIDIA NIM.</p><p className="text-ink-soft">Keys are read only on the server and are never shown here or sent to a model.</p></div>}
      {tab === 'Security' && <ul className="list-disc space-y-1 pl-5 text-sm text-ink-soft"><li>Server-side role checks on every API route</li><li>Secrets stay in environment variables, never in the browser or prompts</li><li>Audit log redacts credentials</li><li>Rate limiting on all API routes (single-instance in demo)</li><li>Tenant isolation and row-level security are designed in the SQL schema for Level 2</li></ul>}
      {tab === 'Billing' && <p className="text-sm text-ink-soft">Billing is a placeholder in this version. Nothing is charged.</p>}
      {tab === 'Audit Logs' && <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left text-sm"><thead className="text-xs text-ink-soft"><tr>{['Time', 'User', 'Agent', 'Action', 'Channel', 'Approval', 'Result'].map(h => <th key={h} className="py-2 pr-3 font-medium">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-paper-line">{state.audit.slice(0, 40).map(e => <tr key={e.id}><td className="py-2 pr-3 whitespace-nowrap">{ago(e.at)}</td><td className="pr-3">{e.user}</td><td className="pr-3">{e.agent ? AGENT_NAMES[e.agent] : '—'}</td><td className="pr-3">{e.action}</td><td className="pr-3">{e.channel ?? '—'}</td><td className="pr-3">{e.approvalState}</td><td><Badge tone={e.result === 'success' ? 'ok' : e.result === 'pending' ? 'spot' : 'bad'}>{e.result}</Badge></td></tr>)}</tbody></table></div>}
    </Card>
    {tab === 'Business' && <div className="mt-4"><Button variant="ghost" onClick={async () => { await call('/api/reset', 'POST'); window.location.href = '/onboarding'; }}>Reset demo data and restart setup</Button></div>}
    {t.node}</>);
}
