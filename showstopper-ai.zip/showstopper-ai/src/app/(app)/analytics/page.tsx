'use client';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Card, CHANNEL_NAMES, PageHeader } from '@/components/ui';
import { LEAD_STATUSES } from '@/lib/types';
function Bar({ label, n, max }: { label: string; n: number; max: number }) {
  return <div className="flex items-center gap-3 text-sm"><span className="w-32 shrink-0 truncate text-ink-soft">{label}</span><div className="h-3 flex-1 rounded-full bg-paper" role="img" aria-label={`${label}: ${n}`}><div className="h-3 rounded-full bg-stage" style={{ width: `${max ? Math.max(4, (n / max) * 100) : 0}%` }} /></div><span className="w-6 text-right font-medium">{n}</span></div>;
}
export default function Analytics() {
  const { state } = useApp(); if (!state) return null; const s = state;
  const won = s.leads.filter(l => l.status === 'Won').length; const conv = s.leads.length ? Math.round((won / s.leads.length) * 100) : 0;
  const byStatus = LEAD_STATUSES.map(x => [x, s.leads.filter(l => l.status === x).length] as const);
  const byCh = Object.entries(CHANNEL_NAMES).map(([k, v]) => [v, s.conversations.filter(c => c.channel === k).length] as const);
  const byAgent = s.agents.map(a => [AGENT_NAMES[a.id], s.audit.filter(e => e.agent === a.id).length + s.tasks.filter(t => t.agent === a.id).length] as const);
  const kp = [['Leads', s.leads.length], ['Conversations', s.conversations.length], ['Conversion', `${conv}%`], ['Tasks completed', s.tasks.filter(t => t.status === 'Done').length], ['Approvals decided', s.approvals.filter(a => a.state !== 'pending').length], ['Median first response', '4 min']];
  return (<><PageHeader title="Analytics" subtitle="Demo data for this version. Response time is illustrative until real channels are connected." />
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">{kp.map(([l, v]) => <Card key={l}><p className="text-2xl font-semibold">{v}</p><p className="text-xs text-ink-soft">{l}</p></Card>)}</div>
    <div className="mt-4 grid gap-4 lg:grid-cols-3">
      <Card><h2 className="mb-3 font-semibold">Leads by status</h2><div className="space-y-2">{byStatus.map(([l, n]) => <Bar key={l} label={l} n={n} max={Math.max(...byStatus.map(x => x[1]))} />)}</div></Card>
      <Card><h2 className="mb-3 font-semibold">Conversations by channel</h2><div className="space-y-2">{byCh.map(([l, n]) => <Bar key={l} label={l} n={n} max={Math.max(...byCh.map(x => x[1]), 1)} />)}</div></Card>
      <Card><h2 className="mb-3 font-semibold">Agent activity</h2><div className="space-y-2">{byAgent.map(([l, n]) => <Bar key={l} label={l} n={n} max={Math.max(...byAgent.map(x => x[1]), 1)} />)}</div></Card></div></>);
}
