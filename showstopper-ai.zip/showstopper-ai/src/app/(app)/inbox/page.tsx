'use client';
import { useMemo, useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Badge, CHANNEL_NAMES, Card, Empty, PageHeader, ago, inputCls, prioTone, useToast, cx } from '@/components/ui';
import type { AgentKey, ChannelId, Conversation } from '@/lib/types';

export default function Inbox() {
  const { state, call } = useApp(); const t = useToast();
  const [q, setQ] = useState(''); const [ch, setCh] = useState<'all' | ChannelId>('all'); const [st, setSt] = useState('all'); const [sel, setSel] = useState<string | null>(null);
  const [note, setNote] = useState(''); const [tag, setTag] = useState('');
  const list = useMemo(() => (state?.conversations ?? []).filter(c => (ch === 'all' || c.channel === ch) && (st === 'all' || c.status === st) &&
    (!q || (c.customerName + c.messages.map(m => m.text).join(' ')).toLowerCase().includes(q.toLowerCase()))).sort((a, b) => b.lastActivity.localeCompare(a.lastActivity)), [state, q, ch, st]);
  if (!state) return null;
  const cur = state.conversations.find(c => c.id === sel) ?? null;
  async function patch(c: Conversation, body: object) { const r = await call(`/api/conversations/${c.id}`, 'PATCH', body); if (!r.ok) t.show(r.error ?? 'Could not update', 'bad'); }
  return (<>
    <PageHeader title="Shared Inbox" subtitle="WhatsApp, Email, Instagram and Website conversations in one place." />
    <div className="mb-3 grid gap-2 sm:grid-cols-[1fr_160px_160px]">
      <input aria-label="Search conversations" className={inputCls} placeholder="Search customers or messages" value={q} onChange={e => setQ(e.target.value)} />
      <select aria-label="Channel" className={inputCls} value={ch} onChange={e => setCh(e.target.value as typeof ch)}><option value="all">All channels</option>{Object.entries(CHANNEL_NAMES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <select aria-label="Status" className={inputCls} value={st} onChange={e => setSt(e.target.value)}><option value="all">All statuses</option>{['Open', 'Waiting', 'Escalated', 'Resolved'].map(s => <option key={s}>{s}</option>)}</select>
    </div>
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <Card pad={false} className={cx(cur && 'hidden lg:block')}>
        {list.length === 0 ? <div className="p-4"><Empty title="No conversations match" hint="Clear the search or filters to see everything." /></div> :
          <ul className="divide-y divide-paper-line">{list.map(c => (<li key={c.id}><button onClick={() => setSel(c.id)} className={cx('w-full px-4 py-3 text-left hover:bg-paper', sel === c.id && 'bg-stage-tint')}>
            <div className="flex items-center justify-between gap-2"><span className="font-medium">{c.customerName}</span><span className="text-xs text-ink-mute">{ago(c.lastActivity)}</span></div>
            <p className="mt-0.5 truncate text-sm text-ink-soft">{c.messages[c.messages.length - 1]?.text}</p>
            <div className="mt-2 flex flex-wrap gap-1.5"><Badge>{CHANNEL_NAMES[c.channel]}</Badge><Badge tone="stage">{AGENT_NAMES[c.assignedAgent]}</Badge><Badge tone={c.status === 'Escalated' ? 'bad' : c.status === 'Resolved' ? 'ok' : 'neutral'}>{c.status}</Badge><Badge tone={prioTone(c.priority)}>{c.priority}</Badge></div>
            <p className="mt-1.5 text-xs text-ink-mute">Next: {c.nextAction}</p></button></li>))}</ul>}
      </Card>
      <div className={cx(!cur && 'hidden lg:block')}>{!cur ? <Empty title="Select a conversation" hint="Reassign an agent, change status, add notes and tags." /> : (
        <Card>
          <button className="mb-2 text-sm text-stage lg:hidden" onClick={() => setSel(null)}>Back to inbox</button>
          <h2 className="font-semibold">{cur.customerName} · {CHANNEL_NAMES[cur.channel]}</h2>
          <ul className="mt-3 max-h-72 space-y-2 overflow-y-auto">{cur.messages.map(m => (<li key={m.id} className={cx('max-w-[85%] rounded-lg px-3 py-2 text-sm', m.from === 'customer' ? 'bg-paper' : 'ml-auto bg-stage-tint')}>{m.text}
            {m.delivery && <span className="mt-1 block text-xs text-ink-mute">{m.delivery === 'draft' ? 'Draft, not sent' : m.delivery === 'blocked' ? 'Not delivered' : 'Sent (demo)'}</span>}</li>))}</ul>
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            <label className="text-xs">Agent<select className={inputCls} value={cur.assignedAgent} onChange={e => patch(cur, { assignedAgent: e.target.value as AgentKey })}>{state.agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
            <label className="text-xs">Status<select className={inputCls} value={cur.status} onChange={e => patch(cur, { status: e.target.value })}>{['Open', 'Waiting', 'Escalated', 'Resolved'].map(s => <option key={s}>{s}</option>)}</select></label>
            <label className="text-xs">Priority<select className={inputCls} value={cur.priority} onChange={e => patch(cur, { priority: e.target.value })}>{['Low', 'Medium', 'High', 'Urgent'].map(s => <option key={s}>{s}</option>)}</select></label>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-1.5">{cur.tags.map(x => <Badge key={x} tone="stage">{x}</Badge>)}
            <form className="flex gap-1" onSubmit={e => { e.preventDefault(); if (tag.trim()) { patch(cur, { addTag: tag }); setTag(''); } }}><input aria-label="Add tag" className={cx(inputCls, '!w-28 !py-1')} placeholder="Add tag" value={tag} onChange={e => setTag(e.target.value)} /></form></div>
          <div className="mt-3"><p className="text-xs font-medium">Notes</p>{cur.notes.map((n, i) => <p key={i} className="mt-1 rounded bg-spot-tint px-2 py-1 text-sm">{n}</p>)}
            <form className="mt-2 flex gap-2" onSubmit={e => { e.preventDefault(); if (note.trim()) { patch(cur, { addNote: note }); setNote(''); } }}><input aria-label="Add note" className={inputCls} placeholder="Add an internal note" value={note} onChange={e => setNote(e.target.value)} /></form></div>
        </Card>)}</div>
    </div>{t.node}</>);
}
