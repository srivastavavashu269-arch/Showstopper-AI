'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Badge, Button, CHANNEL_NAMES, Card, PageHeader, StatusDot, ago, inputCls, riskTone, untilTxt, useToast } from '@/components/ui';
import type { RouteOutcome } from '@/lib/manager';

export default function Dashboard() {
  const { state, call } = useApp(); const toast = useToast();
  const [text, setText] = useState(''); const [busy, setBusy] = useState(false); const [out, setOut] = useState<RouteOutcome | null>(null);
  if (!state) return null;
  const d = state; const pending = d.approvals.filter(a => a.state === 'pending');
  const newLeads = d.leads.filter(l => l.status === 'New').length; const active = d.conversations.filter(c => c.status !== 'Resolved').length;
  const fu = d.leads.filter(l => l.nextFollowUp).length;
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const r = await call<RouteOutcome>('/api/route-task', 'POST', { text, source: 'owner' }); setBusy(false);
    if (r.ok && r.data) { setOut(r.data); setText(''); } else toast.show(r.fields?.text ?? r.error ?? 'Could not route this task', 'bad');
  }
  const kpis = [['New leads', newLeads, '/leads'], ['Active conversations', active, '/inbox'], ['Pending follow-ups', fu, '/leads'], ['Pending approvals', pending.length, '/approvals']] as const;
  return (<>
    <PageHeader title={`Good to see you, ${d.business.name}`} subtitle="Your AI team's work, what needs you, and what is already handled." />
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{kpis.map(([l, n, h]) => (
      <Link key={l} href={h}><Card className="h-full transition-colors hover:border-stage"><p className="text-3xl font-semibold">{n}</p><p className="mt-1 text-sm text-ink-soft">{l}</p></Card></Link>))}</div>

    <Card className="mt-4">
      <h2 className="font-semibold">Give the Central AI Manager a task</h2>
      <p className="mt-1 text-sm text-ink-soft">The manager picks the right specialist. Anything sensitive waits for your approval.</p>
      <form onSubmit={submit} className="mt-3 flex flex-col gap-2 sm:flex-row">
        <input aria-label="Task" className={inputCls} placeholder="e.g. Prepare a quotation for a clinic website" value={text} onChange={e => setText(e.target.value)} />
        <Button disabled={busy || text.trim().length < 2}>{busy ? 'Routing…' : 'Route task'}</Button>
      </form>
      {out && (<div className="mt-3 rounded-lg bg-stage-tint p-3 text-sm" role="status">
        <p><strong>{out.agentName}</strong> took this. <span className="text-ink-soft">{out.reason}</span></p>
        <p className="mt-1">{out.output.result}</p>
        <p className="mt-1 text-ink-soft">Status: {out.output.status.replace('_', ' ')} · Next: {out.output.nextAction}</p>
        {out.knowledge.length > 0 && <p className="mt-1 text-xs text-ink-soft">Sources used: {out.knowledge.map(k => k.source).join(', ')}</p>}
      </div>)}
    </Card>

    <div className="mt-4 grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2"><div className="mb-3 flex items-center justify-between"><h2 className="font-semibold">Needs your decision</h2><Link className="text-sm text-stage" href="/approvals">Open Approval Center</Link></div>
        {pending.length === 0 ? <p className="text-sm text-ink-soft">Nothing is waiting for you.</p> : <ul className="divide-y divide-paper-line">{pending.slice(0, 4).map(a => (
          <li key={a.id} className="flex items-start justify-between gap-3 py-2.5"><div><p className="text-sm font-medium">{a.action}</p><p className="text-sm text-ink-soft">{a.summary.replace(/\s*\[conv:[^\]]+\]/, '')}</p></div><Badge tone={riskTone(a.risk)}>{a.risk} risk</Badge></li>))}</ul>}
      </Card>
      <Card><h2 className="mb-3 font-semibold">Channels</h2><ul className="space-y-2">{d.connections.map(c => (
        <li key={c.channel} className="flex items-center justify-between text-sm"><span>{CHANNEL_NAMES[c.channel]}</span><Badge tone={c.status === 'connected' ? 'ok' : c.status === 'pending' ? 'spot' : c.status === 'error' ? 'bad' : 'neutral'}>{c.status === 'connected' ? 'Connected (demo)' : c.status}</Badge></li>))}</ul>
        <Link className="mt-3 inline-block text-sm text-stage" href="/connections">Manage connections</Link></Card>
    </div>

    <div className="mt-4 grid gap-4 lg:grid-cols-3">
      <Card><h2 className="mb-3 font-semibold">AI team</h2><ul className="space-y-2.5">{d.agents.map(a => (
        <li key={a.id} className="flex items-center justify-between gap-2 text-sm"><span className="flex items-center gap-2"><StatusDot status={a.enabled ? a.status : 'paused'} />{a.name}</span><span className="text-xs text-ink-mute">{a.enabled ? ago(a.lastActivity) : 'Disabled'}</span></li>))}</ul></Card>
      <Card><h2 className="mb-3 font-semibold">Open tasks</h2><ul className="space-y-2.5">{d.tasks.filter(t => t.status !== 'Done').map(t => (
        <li key={t.id} className="text-sm"><p>{t.title}</p><p className="text-xs text-ink-mute">{AGENT_NAMES[t.agent]} · {untilTxt(t.due)}</p></li>))}</ul></Card>
      <Card><h2 className="mb-3 font-semibold">Recent activity</h2><ul className="space-y-2.5">{d.audit.slice(0, 6).map(e => (
        <li key={e.id} className="text-sm"><p>{e.action}</p><p className="text-xs text-ink-mute">{e.agent ? AGENT_NAMES[e.agent] : e.user} · {ago(e.at)} · {e.result}</p></li>))}</ul></Card>
    </div>
    {toast.node}
  </>);
}
