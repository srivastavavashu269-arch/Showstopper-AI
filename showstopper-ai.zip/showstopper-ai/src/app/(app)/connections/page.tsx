'use client';
import { useApp } from '@/components/AppProvider';
import { ConnectionCard } from '@/components/ConnectionCard';
import { PageHeader, Card } from '@/components/ui';
export default function Connections() {
  const { state } = useApp(); if (!state) return null;
  return (<><PageHeader title="Connections" subtitle="A channel counts as connected only after authorization and a successful verification." />
    <Card className="mb-4 bg-spot-tint"><p className="text-sm">This workspace runs in <strong>demo mode</strong>. Connections are simulated locally and never contact WhatsApp, Gmail, Instagram or your website. Real providers arrive in Level 3.</p></Card>
    <div className="grid gap-4 md:grid-cols-2">{state.connections.map(c => <ConnectionCard key={c.channel} conn={c} />)}</div></>);
}
