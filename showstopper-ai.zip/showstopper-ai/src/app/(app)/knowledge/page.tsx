'use client';
import { useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { Badge, Button, Card, Empty, Field, PageHeader, inputCls, useToast } from '@/components/ui';
import type { KnowledgeItem } from '@/lib/types';
const CATS: KnowledgeItem['category'][] = ['Business', 'Services', 'Pricing', 'FAQs', 'Policies', 'Brand Voice', 'Internal Instructions', 'Documents'];
export default function Knowledge() {
  const { state, call } = useApp(); const t = useToast(); const [cat, setCat] = useState<'all' | KnowledgeItem['category']>('all');
  const [f, setF] = useState({ category: 'FAQs', title: '', content: '' }); const [errs, setErrs] = useState<Record<string, string>>({});
  if (!state) return null; const items = state.knowledge.filter(k => cat === 'all' || k.category === cat);
  async function add(e: React.FormEvent) { e.preventDefault(); const r = await call('/api/knowledge', 'POST', f); if (r.ok) { setF({ ...f, title: '', content: '' }); setErrs({}); t.show('Added to knowledge base'); } else setErrs(r.fields ?? { form: r.error ?? 'Could not add' }); }
  return (<><PageHeader title="Knowledge Base" subtitle="Agents retrieve only the approved items that match each question. Unapproved items are never used." />
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <div><div className="mb-3 flex flex-wrap gap-1.5">{(['all', ...CATS] as const).map(c => <button key={c} onClick={() => setCat(c)} className={`rounded-full px-3 py-1.5 text-sm ${cat === c ? 'bg-ink text-white' : 'border border-paper-line bg-white'}`}>{c === 'all' ? 'All' : c}</button>)}</div>
        {items.length === 0 ? <Empty title="Nothing here yet" hint="Add the first item for this category." /> :
          <div className="space-y-3">{items.map(k => (<Card key={k.id}><div className="flex flex-wrap items-start justify-between gap-2"><div><h3 className="font-semibold">{k.title}</h3><Badge tone="stage">{k.category}</Badge></div><Badge tone={k.approved ? 'ok' : 'spot'}>{k.approved ? 'Approved' : 'Not approved'}</Badge></div>
            <p className="mt-2 text-sm text-ink-soft">{k.content}</p>
            <div className="mt-3 flex gap-2"><Button variant="secondary" onClick={async () => { const r = await call(`/api/knowledge/${k.id}`, 'PATCH'); if (!r.ok) t.show(r.error ?? 'Failed', 'bad'); }}>{k.approved ? 'Unapprove' : 'Approve'}</Button>
              <Button variant="ghost" onClick={async () => { const r = await call(`/api/knowledge/${k.id}`, 'DELETE'); if (!r.ok) t.show(r.error ?? 'Failed', 'bad'); }}>Remove</Button></div></Card>))}</div>}</div>
      <Card className="h-fit"><h2 className="font-semibold">Add knowledge</h2><form onSubmit={add} className="mt-3 space-y-3">
        <Field label="Category"><select className={inputCls} value={f.category} onChange={e => setF({ ...f, category: e.target.value })}>{CATS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="Title" error={errs.title}><input className={inputCls} value={f.title} onChange={e => setF({ ...f, title: e.target.value })} /></Field>
        <Field label="Content" error={errs.content}><textarea rows={4} className={inputCls} value={f.content} onChange={e => setF({ ...f, content: e.target.value })} /></Field>
        <Button>Add item</Button>{errs.form && <p role="alert" className="text-sm text-bad">{errs.form}</p>}</form></Card></div>{t.node}</>);
}
