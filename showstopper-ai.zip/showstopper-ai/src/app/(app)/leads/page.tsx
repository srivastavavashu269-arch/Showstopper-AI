'use client';
import { useMemo, useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Badge, Button, CHANNEL_NAMES, Card, Empty, Field, PageHeader, inputCls, prioTone, untilTxt, useToast } from '@/components/ui';
import { LEAD_STATUSES, type Lead } from '@/lib/types';

const blank = { name: '', email: '', phone: '', company: '', requirement: '', budget: '', channel: 'website', priority: 'Medium' };
export default function Leads() {
  const { state, call } = useApp(); const t = useToast();
  const [q, setQ] = useState(''); const [st, setSt] = useState('all'); const [adding, setAdding] = useState(false); const [f, setF] = useState(blank); const [errs, setErrs] = useState<Record<string, string>>({}); const [edit, setEdit] = useState<string | null>(null);
  const leads = useMemo(() => (state?.leads ?? []).filter(l => (st === 'all' || l.status === st) && (!q || (l.name + l.company + l.requirement).toLowerCase().includes(q.toLowerCase()))), [state, q, st]);
  if (!state) return null;
  async function create(e: React.FormEvent) { e.preventDefault(); const r = await call('/api/leads', 'POST', f); if (r.ok) { setAdding(false); setF(blank); setErrs({}); t.show('Lead added'); } else setErrs(r.fields ?? { form: r.error ?? 'Could not add lead' }); }
  async function patch(l: Lead, body: object) { const r = await call(`/api/leads/${l.id}`, 'PATCH', body); if (!r.ok) t.show(r.error ?? 'Could not update lead', 'bad'); }
  const ed = state.leads.find(l => l.id === edit);
  return (<>
    <PageHeader title="Leads / CRM" subtitle="Every lead your AI team captures, with status, owner agent and next follow-up." actions={<Button onClick={() => setAdding(!adding)}>{adding ? 'Cancel' : 'Add lead'}</Button>} />
    {adding && <Card className="mb-4"><form onSubmit={create} className="grid gap-3 sm:grid-cols-2">
      <Field label="Name" error={errs.name}><input className={inputCls} value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
      <Field label="Company"><input className={inputCls} value={f.company} onChange={e => setF({ ...f, company: e.target.value })} /></Field>
      <Field label="Email" error={errs.email}><input className={inputCls} value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /></Field>
      <Field label="Phone"><input className={inputCls} value={f.phone} onChange={e => setF({ ...f, phone: e.target.value })} /></Field>
      <Field label="Channel"><select className={inputCls} value={f.channel} onChange={e => setF({ ...f, channel: e.target.value })}>{Object.entries(CHANNEL_NAMES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
      <Field label="Budget"><input className={inputCls} value={f.budget} onChange={e => setF({ ...f, budget: e.target.value })} /></Field>
      <div className="sm:col-span-2"><Field label="Requirement"><textarea rows={2} className={inputCls} value={f.requirement} onChange={e => setF({ ...f, requirement: e.target.value })} /></Field></div>
      <div className="sm:col-span-2"><Button>Save lead</Button>{errs.form && <span role="alert" className="ml-3 text-sm text-bad">{errs.form}</span>}</div></form></Card>}
    <div className="mb-3 grid gap-2 sm:grid-cols-[1fr_200px]"><input aria-label="Search leads" className={inputCls} placeholder="Search name, company or requirement" value={q} onChange={e => setQ(e.target.value)} />
      <select aria-label="Status" className={inputCls} value={st} onChange={e => setSt(e.target.value)}><option value="all">All statuses</option>{LEAD_STATUSES.map(s => <option key={s}>{s}</option>)}</select></div>
    {leads.length === 0 ? <Empty title="No leads match" hint="Try a different search or add a new lead." /> :
      <Card pad={false} className="overflow-x-auto"><table className="w-full min-w-[820px] text-left text-sm"><thead className="border-b border-paper-line text-xs text-ink-soft"><tr>{['Lead', 'Requirement', 'Channel', 'Status', 'Priority', 'Agent', 'Next follow-up'].map(h => <th key={h} className="px-4 py-2.5 font-medium">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-paper-line">{leads.map(l => (<tr key={l.id} className="cursor-pointer hover:bg-paper" onClick={() => setEdit(l.id)}>
          <td className="px-4 py-3"><p className="font-medium">{l.name}</p><p className="text-xs text-ink-mute">{l.company}</p></td><td className="max-w-[220px] truncate px-4 py-3 text-ink-soft">{l.requirement}</td>
          <td className="px-4 py-3">{CHANNEL_NAMES[l.channel]}</td><td className="px-4 py-3" onClick={e => e.stopPropagation()}><select aria-label={`Status for ${l.name}`} className="rounded-lg border border-paper-line bg-white px-2 py-1 text-sm" value={l.status} onChange={e => patch(l, { status: e.target.value })}>{LEAD_STATUSES.map(s => <option key={s}>{s}</option>)}</select></td>
          <td className="px-4 py-3"><Badge tone={prioTone(l.priority)}>{l.priority}</Badge></td><td className="px-4 py-3">{AGENT_NAMES[l.assignedAgent]}</td><td className="px-4 py-3">{untilTxt(l.nextFollowUp)}</td></tr>))}</tbody></table></Card>}
    {ed && <Card className="mt-4"><div className="flex justify-between"><h2 className="font-semibold">{ed.name}</h2><button className="text-sm text-stage" onClick={() => setEdit(null)}>Close</button></div>
      <p className="mt-1 text-sm text-ink-soft">{ed.email} · {ed.phone} · Budget: {ed.budget || 'Not shared'}</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-3"><Field label="Priority"><select className={inputCls} value={ed.priority} onChange={e => patch(ed, { priority: e.target.value })}>{['Low', 'Medium', 'High', 'Urgent'].map(p => <option key={p}>{p}</option>)}</select></Field>
        <Field label="Assigned agent"><select className={inputCls} value={ed.assignedAgent} onChange={e => patch(ed, { assignedAgent: e.target.value })}>{state.agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field>
        <Field label="Next follow-up"><input type="datetime-local" className={inputCls} defaultValue={ed.nextFollowUp ? ed.nextFollowUp.slice(0, 16) : ''} onBlur={e => patch(ed, { nextFollowUp: e.target.value ? new Date(e.target.value).toISOString() : null })} /></Field></div>
      <div className="mt-3"><Field label="Notes"><textarea rows={3} className={inputCls} defaultValue={ed.notes} onBlur={e => e.target.value !== ed.notes && patch(ed, { notes: e.target.value })} /></Field></div></Card>}
    {t.node}</>);
}
