'use client';
import { useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { Badge, Button, Card, Empty, PageHeader, ago, inputCls, riskTone, useToast } from '@/components/ui';

export default function Approvals() {
  const { state, call } = useApp(); const t = useToast(); const [notes, setNotes] = useState<Record<string, string>>({}); const [busy, setBusy] = useState<string | null>(null);
  if (!state) return null; const pending = state.approvals.filter(a => a.state === 'pending'); const done = state.approvals.filter(a => a.state !== 'pending');
  async function decide(id: string, decision: string) {
    setBusy(id); const r = await call<{ execution?: { ok: boolean; message: string } }>(`/api/approvals/${id}`, 'POST', { decision, note: notes[id] }); setBusy(null);
    if (!r.ok) return t.show(r.error ?? 'Could not record decision', 'bad');
    const ex = r.data?.execution; t.show(ex ? ex.message : 'Decision recorded', ex && !ex.ok ? 'bad' : 'ok');
  }
  return (<>
    <PageHeader title="Approval Center" subtitle="Sensitive actions wait here. Nothing is sent, published or deployed until you approve." />
    {pending.length === 0 ? <Empty title="You are all caught up" hint="New requests from your agents will appear here." /> :
      <div className="space-y-3">{pending.map(a => (<Card key={a.id}>
        <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="font-semibold">{a.action}</h2><p className="text-sm text-ink-soft">{a.summary.replace(/\s*\[conv:[^\]]+\]/, '')}</p></div><Badge tone={riskTone(a.risk)}>{a.risk} risk</Badge></div>
        <p className="mt-2 text-xs text-ink-mute">Requested by {a.requestedBy} · {a.business} · {ago(a.date)}</p>
        <input aria-label="Decision note" className={inputCls + ' mt-3'} placeholder="Optional note to the agent" value={notes[a.id] ?? ''} onChange={e => setNotes({ ...notes, [a.id]: e.target.value })} />
        <div className="mt-3 flex flex-wrap gap-2"><Button disabled={busy === a.id} onClick={() => decide(a.id, 'approve')}>Approve</Button><Button variant="secondary" disabled={busy === a.id} onClick={() => decide(a.id, 'request_changes')}>Request changes</Button><Button variant="danger" disabled={busy === a.id} onClick={() => decide(a.id, 'reject')}>Reject</Button></div>
      </Card>))}</div>}
    <h2 className="mb-2 mt-8 font-semibold">History</h2>
    <Card pad={false}><ul className="divide-y divide-paper-line">{done.map(a => (<li key={a.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm"><span>{a.action} · {a.requestedBy}</span><Badge tone={a.state === 'approved' ? 'ok' : a.state === 'rejected' ? 'bad' : 'spot'}>{a.state.replace('_', ' ')}</Badge></li>))}{done.length === 0 && <li className="px-4 py-3 text-sm text-ink-soft">No decisions yet.</li>}</ul></Card>{t.node}</>);
}
