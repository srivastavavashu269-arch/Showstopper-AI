'use client';
import { useState } from 'react';
import { useApp } from '@/components/AppProvider';
import { Badge, Button, Card, Field, PageHeader, StatusDot, ago, inputCls, useToast } from '@/components/ui';
import { TOOL_LABEL, TOOL_RISK } from '@/lib/permissions';
import type { Agent, ToolId } from '@/lib/types';

const LEVELS = [['read_only', 'Read only'], ['draft_only', 'Draft only'], ['act_with_approval', 'Act with approval'], ['act_autonomously', 'Act on its own']] as const;

export default function Agents() {
  const { state, call } = useApp(); const t = useToast(); const [open, setOpen] = useState<string | null>(null); const [mOpen, setMOpen] = useState(false);
  if (!state) return null; const isOwner = state.session.role === 'owner';
  async function patch(a: Agent, body: object) { const r = await call(`/api/agents/${a.id}`, 'PATCH', body); if (!r.ok) t.show(r.error ?? 'Could not save', 'bad'); else t.show('Saved'); }
  return (<>
    <PageHeader title="AI Agents" subtitle="Configure what each specialist knows, may use, and may do on its own." />
    <Card className="mb-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><h2 className="font-semibold">{state.manager.name}</h2><p className="text-sm text-ink-soft">Central AI Manager · {state.manager.routingStrategy} routing · {state.manager.approvalMode} approvals</p></div><Button variant="secondary" onClick={() => setMOpen(!mOpen)}>{mOpen ? 'Close' : 'Configure manager'}</Button></div>
      {mOpen && <ManagerForm />}</Card>
    <div className="grid gap-4 md:grid-cols-2">{state.agents.map(a => (
      <Card key={a.id}>
        <div className="flex items-start justify-between gap-2"><div><h3 className="flex items-center gap-2 font-semibold"><StatusDot status={a.enabled ? a.status : 'paused'} />{a.name}</h3><p className="text-sm text-ink-soft">{a.description}</p></div>
          <Badge tone={a.enabled ? 'ok' : 'neutral'}>{a.enabled ? (a.status === 'paused' ? 'Paused' : 'Active') : 'Disabled'}</Badge></div>
        <p className="mt-2 text-xs text-ink-mute">Last activity {ago(a.lastActivity)} · {a.requiresApproval ? 'Approval required for impactful actions' : 'No extra approval'}</p>
        <div className="mt-3 flex gap-2"><Button variant="secondary" onClick={() => setOpen(open === a.id ? null : a.id)}>{open === a.id ? 'Close' : 'Configure'}</Button>
          <Button variant="ghost" onClick={() => patch(a, { enabled: !a.enabled })}>{a.enabled ? 'Disable' : 'Enable'}</Button>
          <Button variant="ghost" disabled={!a.enabled} onClick={() => patch(a, { status: a.status === 'paused' ? 'idle' : 'paused' })}>{a.status === 'paused' ? 'Resume' : 'Pause'}</Button></div>
        {open === a.id && <AgentForm a={a} onSave={b => patch(a, b)} />}
        <ActivityList agent={a.id} />
      </Card>))}</div>
    {!isOwner && <p className="mt-4 text-sm text-ink-soft">Some changes need the Owner or Admin role.</p>}{t.node}</>);
}
function ActivityList({ agent }: { agent: Agent['id'] }) {
  const { state } = useApp(); const ev = state!.audit.filter(e => e.agent === agent).slice(0, 3);
  return <div className="mt-3 border-t border-paper-line pt-2"><p className="text-xs font-medium">Activity history</p>{ev.length === 0 ? <p className="text-xs text-ink-mute">No activity yet.</p> : <ul className="mt-1 space-y-0.5">{ev.map(e => <li key={e.id} className="text-xs text-ink-soft">{e.action} · {ago(e.at)} · {e.result}</li>)}</ul>}</div>;
}
function AgentForm({ a, onSave }: { a: Agent; onSave: (b: object) => void }) {
  const [name, setName] = useState(a.name); const [ins, setIns] = useState(a.instructions); const [lvl, setLvl] = useState(a.permissionLevel); const [req, setReq] = useState(a.requiresApproval); const [tools, setTools] = useState<ToolId[]>(a.allowedTools);
  const all = Object.keys(TOOL_LABEL) as ToolId[];
  return (<div className="mt-3 space-y-3 border-t border-paper-line pt-3">
    <Field label="Name"><input className={inputCls} value={name} onChange={e => setName(e.target.value)} /></Field>
    <Field label="Instructions"><textarea rows={4} className={inputCls} value={ins} onChange={e => setIns(e.target.value)} /></Field>
    <Field label="Permission level"><select className={inputCls} value={lvl} onChange={e => setLvl(e.target.value as typeof lvl)}>{LEVELS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
    <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#4B3FE0]" checked={req} onChange={e => setReq(e.target.checked)} />Require my approval for impactful actions</label>
    <fieldset><legend className="text-sm font-medium">Allowed tools</legend><div className="mt-1 grid gap-1 sm:grid-cols-2">{all.map(tl => (<label key={tl} className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4B3FE0]" checked={tools.includes(tl)} onChange={e => setTools(e.target.checked ? [...tools, tl] : tools.filter(x => x !== tl))} />{TOOL_LABEL[tl]}{TOOL_RISK[tl] === 'High' && <Badge tone="bad">approval</Badge>}</label>))}</div></fieldset>
    <Button onClick={() => onSave({ name, instructions: ins, permissionLevel: lvl, requiresApproval: req, allowedTools: tools })}>Save agent</Button></div>);
}
function ManagerForm() {
  const { state, call } = useApp(); const m = state!.manager; const t = useToast();
  const [name, setName] = useState(m.name); const [ins, setIns] = useState(m.instructions); const [esc, setEsc] = useState(m.escalationRules); const [mode, setMode] = useState(m.approvalMode); const [strat, setStrat] = useState(m.routingStrategy); const [allowed, setAllowed] = useState<string[]>(m.allowedAgents); const [errs, setErrs] = useState<Record<string, string>>({});
  async function save() { const r = await call('/api/manager', 'PATCH', { name, instructions: ins, escalationRules: esc, approvalMode: mode, routingStrategy: strat, allowedAgents: allowed }); if (r.ok) { setErrs({}); t.show('Manager saved'); } else { setErrs(r.fields ?? {}); t.show(r.error ?? 'Could not save', 'bad'); } }
  return (<div className="mt-3 space-y-3 border-t border-paper-line pt-3"><Field label="Manager name" error={errs.name}><input className={inputCls} value={name} onChange={e => setName(e.target.value)} /></Field>
    <Field label="Manager instructions" error={errs.instructions}><textarea rows={8} className={inputCls} value={ins} onChange={e => setIns(e.target.value)} /></Field>
    <div className="grid gap-3 sm:grid-cols-2"><Field label="Routing strategy"><select className={inputCls} value={strat} onChange={e => setStrat(e.target.value as typeof strat)}><option value="rules">Rules</option><option value="ai_assisted">AI-assisted</option><option value="hybrid">Hybrid</option></select></Field>
      <Field label="Approval mode"><select className={inputCls} value={mode} onChange={e => setMode(e.target.value as typeof mode)}><option value="strict">Strict</option><option value="balanced">Balanced</option><option value="relaxed">Relaxed</option></select></Field></div>
    <Field label="Escalation rules"><textarea rows={2} className={inputCls} value={esc} onChange={e => setEsc(e.target.value)} /></Field>
    <fieldset><legend className="text-sm font-medium">Allowed agents</legend><div className="mt-1 flex flex-wrap gap-3">{state!.agents.map(a => <label key={a.id} className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4B3FE0]" checked={allowed.includes(a.id)} onChange={e => setAllowed(e.target.checked ? [...allowed, a.id] : allowed.filter(x => x !== a.id))} />{a.name}</label>)}</div></fieldset>
    <Button onClick={save}>Save manager</Button>{t.node}</div>);
}
