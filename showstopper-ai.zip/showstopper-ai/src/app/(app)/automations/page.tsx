'use client';
import { useApp } from '@/components/AppProvider';
import { AGENT_NAMES, Badge, Button, Card, PageHeader, untilTxt, useToast } from '@/components/ui';
export default function Automations() {
  const { state, call } = useApp(); const t = useToast(); if (!state) return null;
  const fu = state.leads.filter(l => l.nextFollowUp && !['Won', 'Lost'].includes(l.status)).sort((a, b) => a.nextFollowUp!.localeCompare(b.nextFollowUp!));
  return (<><PageHeader title="Automations" subtitle="Rules that put your agents to work. Outbound messages from automations still go through approval." />
    <div className="space-y-3">{state.automations.map(a => (<Card key={a.id}><div className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="font-semibold">{a.name}</h3><p className="text-sm text-ink-soft">When: {a.trigger}</p><p className="text-sm text-ink-soft">Then: {a.action}</p><p className="mt-1 text-xs text-ink-mute">{AGENT_NAMES[a.agent]}</p></div>
      <div className="flex items-center gap-2"><Badge tone={a.enabled ? 'ok' : 'neutral'}>{a.enabled ? 'On' : 'Off'}</Badge><Button variant="secondary" onClick={async () => { const r = await call(`/api/automations/${a.id}`, 'PATCH'); if (!r.ok) t.show(r.error ?? 'Failed', 'bad'); }}>{a.enabled ? 'Turn off' : 'Turn on'}</Button></div></div></Card>))}</div>
    <h2 className="mb-2 mt-8 font-semibold">Upcoming follow-ups</h2>
    <Card pad={false}><ul className="divide-y divide-paper-line">{fu.map(l => <li key={l.id} className="flex justify-between gap-2 px-4 py-3 text-sm"><span>{l.name} · {l.company}</span><span className="text-ink-soft">{untilTxt(l.nextFollowUp)}</span></li>)}</ul></Card>{t.node}</>);
}
