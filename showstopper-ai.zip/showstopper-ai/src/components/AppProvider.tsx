'use client';
import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { Agent, Approval, AuditEvent, Automation, Business, Connection, Conversation, KnowledgeItem, Lead, ManagerConfig, Notification, Role, Task } from '@/lib/types';

export interface AppState {
  session: { user: string; role: Role }; business: Business; manager: ManagerConfig; agents: Agent[]; knowledge: KnowledgeItem[]; leads: Lead[];
  conversations: Conversation[]; approvals: Approval[]; tasks: Task[]; connections: Connection[]; automations: Automation[]; audit: AuditEvent[]; notifications: Notification[];
}
export interface ApiResult<T = unknown> { ok: boolean; data?: T; error?: string; fields?: Record<string, string> }
interface Ctx { state: AppState | null; loading: boolean; error: string | null; refresh: () => Promise<void>; call: <T = unknown>(url: string, method: string, body?: unknown) => Promise<ApiResult<T>> }
const C = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const refresh = useCallback(async () => {
    try { const r = await fetch('/api/state', { cache: 'no-store' }); const j = await r.json();
      if (!j.ok) throw new Error(j.error); setState(j.data); setError(null); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not load your workspace'); } finally { setLoading(false); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  const call = useCallback(async <T,>(url: string, method: string, body?: unknown): Promise<ApiResult<T>> => {
    try { const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
      const j = (await r.json()) as ApiResult<T>; if (j.ok) await refresh(); return j; }
    catch { return { ok: false, error: 'Network problem. Check your connection and try again.' }; }
  }, [refresh]);
  return <C.Provider value={{ state, loading, error, refresh, call }}>{children}</C.Provider>;
}
export function useApp() { const c = useContext(C); if (!c) throw new Error('useApp outside provider'); return c; }
