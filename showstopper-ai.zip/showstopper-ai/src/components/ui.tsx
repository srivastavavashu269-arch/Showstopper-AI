'use client';
import { useEffect, useState } from 'react';
import type { AgentKey } from '@/lib/types';

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ');
export function Card({ children, className, pad = true }: { children: React.ReactNode; className?: string; pad?: boolean }) {
  return <section className={cx('rounded-card border border-paper-line bg-paper-card', pad && 'p-4 sm:p-5', className)}>{children}</section>;
}
export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (<div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-2xl font-semibold tracking-tight">{title}</h1>{subtitle && <p className="mt-1 max-w-2xl text-sm text-ink-soft">{subtitle}</p>}</div>{actions && <div className="flex flex-wrap gap-2">{actions}</div>}</div>);
}
const TONES = { neutral: 'bg-paper text-ink-soft', stage: 'bg-stage-tint text-stage-deep', spot: 'bg-spot-tint text-[#8A5A00]', ok: 'bg-ok-tint text-ok', bad: 'bg-bad-tint text-bad' };
export function Badge({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: keyof typeof TONES }) {
  return <span className={cx('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium', TONES[tone])}>{children}</span>;
}
export function Button({ variant = 'primary', className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost' }) {
  const v = { primary: 'bg-stage text-white hover:bg-stage-deep', secondary: 'border border-paper-line bg-white text-ink hover:bg-paper', danger: 'bg-bad text-white hover:opacity-90', ghost: 'text-ink-soft hover:bg-paper' }[variant];
  return <button {...p} className={cx('inline-flex min-h-[40px] items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50', v, className)} />;
}
export function Field({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: React.ReactNode }) {
  return (<label className="block text-sm"><span className="mb-1 block font-medium">{label}</span>{children}{hint && !error && <span className="mt-1 block text-xs text-ink-mute">{hint}</span>}{error && <span role="alert" className="mt-1 block text-xs text-bad">{error}</span>}</label>);
}
export const inputCls = 'w-full rounded-lg border border-paper-line bg-white px-3 py-2 text-sm placeholder:text-ink-mute focus:border-stage';
export function Empty({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (<div className="rounded-card border border-dashed border-paper-line p-8 text-center"><p className="font-medium">{title}</p>{hint && <p className="mt-1 text-sm text-ink-soft">{hint}</p>}{action && <div className="mt-3">{action}</div>}</div>);
}
export function Toast({ msg, tone = 'ok', onDone }: { msg: string; tone?: 'ok' | 'bad'; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 4500); return () => clearTimeout(t); }, [onDone]);
  return <div role="status" className={cx('fixed bottom-4 right-4 z-50 max-w-sm rounded-lg px-4 py-3 text-sm shadow-lg', tone === 'ok' ? 'bg-ink text-white' : 'bg-bad text-white')}>{msg}</div>;
}
export function useToast() {
  const [t, setT] = useState<{ msg: string; tone: 'ok' | 'bad' } | null>(null);
  return { show: (msg: string, tone: 'ok' | 'bad' = 'ok') => setT({ msg, tone }), node: t ? <Toast msg={t.msg} tone={t.tone} onDone={() => setT(null)} /> : null };
}
export const AGENT_NAMES: Record<AgentKey, string> = { manager: 'Central Manager', sales: 'Sales & Lead', marketing: 'Marketing', support: 'Customer Support', webdev: 'Web Development', research: 'Research', followup: 'Follow-up' };
export const CHANNEL_NAMES = { whatsapp: 'WhatsApp', email: 'Email', instagram: 'Instagram', website: 'Website' } as const;
export function StatusDot({ status }: { status: string }) {
  const c = status === 'working' ? 'bg-stage pulse-working' : status === 'idle' ? 'bg-ok' : status === 'paused' ? 'bg-ink-mute' : 'bg-spot';
  return <span className={cx('inline-block h-2.5 w-2.5 rounded-full', c)} aria-hidden />;
}
export const riskTone = (r: string) => (r === 'High' ? 'bad' : r === 'Medium' ? 'spot' : 'ok') as 'bad' | 'spot' | 'ok';
export const prioTone = (p: string) => (p === 'Urgent' ? 'bad' : p === 'High' ? 'spot' : 'neutral') as 'bad' | 'spot' | 'neutral';
export function ago(iso: string) {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (m < 1) return 'just now'; if (m < 60) return `${m} min ago`; if (m < 1440) return `${Math.round(m / 60)} h ago`; return `${Math.round(m / 1440)} d ago`;
}
export function untilTxt(iso: string | null) {
  if (!iso) return 'Not scheduled'; const h = Math.round((new Date(iso).getTime() - Date.now()) / 3600000);
  return h <= 0 ? 'Due now' : h < 24 ? `In ${h} h` : `In ${Math.round(h / 24)} d`;
}
