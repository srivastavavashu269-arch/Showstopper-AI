'use client';
import { useState } from 'react';
import { useApp } from './AppProvider';
import { Badge, Button, Card, CHANNEL_NAMES, Field, inputCls, useToast, ago } from './ui';
import type { Connection } from '@/lib/types';

const HINT = { whatsapp: 'WhatsApp number, e.g. +91 98765 43210', email: 'Email address, e.g. hello@yourbusiness.com', instagram: 'Instagram username, e.g. @yourbusiness', website: 'Website URL, e.g. https://yourbusiness.com' } as const;
const NOTE = {
  whatsapp: 'Live: official WhatsApp Business Cloud API with webhooks (Level 3).',
  email: 'Live: Google Workspace / Gmail via OAuth. Passwords are never requested (Level 3).',
  instagram: 'Live: official Meta authorization for messaging, publishing and insights (Level 3).',
  website: 'A URL alone allows public analysis only. Managing a site needs real admin authorization (Level 3).',
} as const;

export function ConnectionCard({ conn, compact }: { conn: Connection; compact?: boolean }) {
  const { call } = useApp(); const t = useToast();
  const [val, setVal] = useState(conn.identifier); const [busy, setBusy] = useState(false); const [show, setShow] = useState(false);
  async function act(action: 'connect' | 'verify' | 'disconnect') {
    setBusy(true); const r = await call<Connection>(`/api/connections/${conn.channel}`, 'POST', { action, identifier: val }); setBusy(false);
    if (!r.ok) return t.show(r.error ?? 'Request failed', 'bad');
    if (r.data?.status === 'error') return t.show(r.data.lastError ?? 'Could not connect', 'bad');
    t.show(action === 'connect' ? 'Details saved. Run the test to verify the connection.' : action === 'verify' ? 'Verified in demo mode.' : 'Disconnected.');
  }
  const tone = conn.status === 'connected' ? 'ok' : conn.status === 'pending' ? 'spot' : conn.status === 'error' ? 'bad' : 'neutral';
  const label = conn.status === 'connected' ? 'Connected (demo)' : conn.status === 'pending' ? 'Not verified yet' : conn.status === 'error' ? 'Needs attention' : 'Not connected';
  return (
    <Card>
      <div className="flex items-start justify-between gap-2"><div><h3 className="font-semibold">{CHANNEL_NAMES[conn.channel]}</h3><p className="mt-0.5 text-xs text-ink-soft">{NOTE[conn.channel]}</p></div><Badge tone={tone}>{label}</Badge></div>
      {conn.status === 'connected' && <p className="mt-2 text-sm text-ink-soft">{conn.identifier} · verified {conn.verifiedAt ? ago(conn.verifiedAt) : ''}</p>}
      {conn.status === 'pending' && <p className="mt-2 text-sm text-ink-soft">{conn.identifier} was saved. It is not connected until you run Test connection.</p>}
      {(conn.status === 'disconnected' || conn.status === 'error') && (
        <div className="mt-3"><Field label={HINT[conn.channel]} error={conn.lastError}><input className={inputCls} value={val} onChange={e => setVal(e.target.value)} /></Field></div>)}
      <div className="mt-3 flex flex-wrap gap-2">
        {(conn.status === 'disconnected' || conn.status === 'error') && <Button disabled={busy} onClick={() => act('connect')}>Connect</Button>}
        <Button variant="secondary" disabled={busy || conn.status === 'disconnected'} onClick={() => act('verify')}>Test connection</Button>
        <Button variant="secondary" disabled={conn.status !== 'connected'} onClick={() => setShow(!show)}>Manage permissions</Button>
        <Button variant="ghost" disabled={busy || conn.status === 'disconnected'} onClick={() => act('disconnect')}>Disconnect</Button>
      </div>
      {show && conn.status === 'connected' && !compact && <ul className="mt-3 list-disc pl-5 text-sm text-ink-soft">{conn.permissions.map(p => <li key={p}>{p}</li>)}</ul>}
      {show && compact && <p className="mt-2 text-xs text-ink-soft">Granted: {conn.permissions.join(', ')}</p>}
      {t.node}
    </Card>
  );
}
